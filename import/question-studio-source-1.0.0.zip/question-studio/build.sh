#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p .cache release
x86_64-w64-mingw32-windres --codepage=65001 -I assets assets/app.rc .cache/app-res.o
x86_64-w64-mingw32-g++ -std=c++17 -O2 -s -municode -mwindows -Wl,--no-insert-timestamp,--major-subsystem-version,6,--minor-subsystem-version,0 -static -static-libgcc -static-libstdc++ -DUNICODE -D_UNICODE -DWINVER=0x0A00 -D_WIN32_WINNT=0x0A00 -Wall -Wextra -Wno-missing-field-initializers src/main.cpp .cache/app-res.o -o release/QuestionStudio.exe -lcomctl32 -lcomdlg32 -lgdi32 -luser32 -lshell32 -lole32 -luxtheme -ldwmapi -luuid
printf '\nBuilt: '; ls -lh release/QuestionStudio.exe
