// SPDX-License-Identifier: GPL-2.0-or-later
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shlobj.h>
#include <shellapi.h>
#include <uxtheme.h>
#include <dwmapi.h>
#include <fstream>
#include <functional>
#include "core.hpp"
#include "samples.hpp"

using namespace studio;
namespace {
constexpr COLORREF BG=RGB(242,246,245), WHITE=RGB(255,255,255), INK=RGB(24,48,50), MUTED=RGB(100,119,120), LINE=RGB(218,229,226), TEAL=RGB(17,124,112), PALE=RGB(229,244,239), NAV=RGB(20,43,45), NAVSEL=RGB(32,76,74), NAVMUTED=RGB(150,178,175);
constexpr int ID_LIST=100,ID_NAME=101,ID_NEW=102,ID_OPEN=103,ID_SAVE=104,ID_CHECK=105,ID_EXPORT=106,ID_HELP=107,ID_ADD=108,ID_COPY=109,ID_DELETE=110,ID_UP=111,ID_DOWN=112,ID_SAVEAS=113,ID_EXAMPLE=114,ID_ALLSAMPLES=115,ID_XLSX=116,ID_CSV=117,ID_JSON=118,ID_EXIT=119,ID_TAB0=120,ID_TAB1=121,ID_TAB2=122,ID_TYPE=123,ID_CURRENTEXAMPLE=124;
constexpr UINT TIMER_REFRESH=1,TIMER_RECOVERY=2;
HINSTANCE instance;
HWND win=nullptr,form=nullptr,list=nullptr,nameEdit=nullptr;
std::map<int,HWND> controls;
HFONT font=nullptr,smallFont=nullptr,boldFont=nullptr,titleFont=nullptr,headingFont=nullptr;
HBRUSH bgBrush=nullptr,whiteBrush=nullptr,navBrush=nullptr;
int dpi=96,side=274,active=0,tab=0,scrollY=0,contentHeight=0;
bool loading=false,dirty=false,closing=false;
Project project;
std::wstring projectPath,recoveryPath;
std::wstring statusText=L"Готово к работе. Добавьте вопрос или откройте пример.";
struct Binding {HWND h;std::string kind,key;int index=0;std::vector<std::string> codes;};
std::vector<Binding> bindings;
struct Placement {HWND h;int x,y,w,hgt;};
std::vector<Placement> placements;
std::map<int,std::pair<std::string,int>> actions;
int nextId=2000;
int S(int n){return MulDiv(n,dpi,96);}
std::wstring wide(const std::string& s){if(s.empty())return{};int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,s.data(),(int)s.size(),nullptr,0);if(!n)throw std::runtime_error("Некорректная кодировка UTF-8.");std::wstring o(n,0);MultiByteToWideChar(CP_UTF8,0,s.data(),s.size(),o.data(),n);return o;}
std::string utf8(const std::wstring& s){if(s.empty())return{};int n=WideCharToMultiByte(CP_UTF8,0,s.data(),s.size(),nullptr,0,nullptr,nullptr);std::string o(n,0);WideCharToMultiByte(CP_UTF8,0,s.data(),s.size(),o.data(),n,nullptr,nullptr);return o;}
std::wstring text(HWND h){int n=GetWindowTextLengthW(h);std::wstring s(n+1,0);GetWindowTextW(h,s.data(),n+1);s.resize(n);return s;}
std::string editText(HWND h){return utf8(text(h));}
std::wstring osError(){DWORD e=GetLastError();LPWSTR p=nullptr;FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,nullptr,e,0,(LPWSTR)&p,0,nullptr);std::wstring s=p?p:L"Неизвестная ошибка Windows";if(p)LocalFree(p);return s;}
void error(const std::wstring& s){MessageBoxW(win,s.c_str(),L"Редактор вопросов",MB_OK|MB_ICONERROR);}
void writeFile(const std::wstring& path,const std::string& data){
    std::wstring temp=path+L".tmp-"+std::to_wstring(GetCurrentProcessId());
    HANDLE f=CreateFileW(temp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(f==INVALID_HANDLE_VALUE)throw std::runtime_error("Не удалось записать файл. "+utf8(osError()));
    size_t at=0;bool ok=true;
    while(at<data.size()){DWORD n=0;DWORD part=(DWORD)std::min<size_t>(data.size()-at,1024*1024);if(!WriteFile(f,data.data()+at,part,&n,nullptr)||n==0){ok=false;break;}at+=n;}
    if(ok) ok=FlushFileBuffers(f);
    auto cause=GetLastError();CloseHandle(f);
    if(!ok){DeleteFileW(temp.c_str());SetLastError(cause);throw std::runtime_error("Не удалось сохранить файл. "+utf8(osError()));}
    if(!MoveFileExW(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){auto reason=osError();DeleteFileW(temp.c_str());throw std::runtime_error("Не удалось заменить файл. "+utf8(reason));}
}
std::string readFile(const std::wstring& path){
    HANDLE f=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(f==INVALID_HANDLE_VALUE)throw std::runtime_error("Не удалось открыть файл. "+utf8(osError()));
    LARGE_INTEGER size;if(!GetFileSizeEx(f,&size)||size.QuadPart<0||size.QuadPart>(LONGLONG)MAX_FILE){CloseHandle(f);throw std::runtime_error("Не удалось прочитать файл: максимум 24 МБ.");}
    std::string s((size_t)size.QuadPart,0);DWORD n=0;bool ok=ReadFile(f,s.data(),s.size(),&n,nullptr);CloseHandle(f);
    if(!ok||n!=s.size()) throw std::runtime_error("Файл прочитан не полностью.");
    return s;
}
std::wstring cleanName(const std::string& name){auto n=wide(name);for(auto& c:n)if(c<32||std::wstring(L"<>:\"/\\|?*").find(c)!=std::wstring::npos)c=L'_';while(!n.empty()&&(n.back()==L' '||n.back()==L'.'))n.pop_back();if(n.empty())n=L"Набор вопросов";if(n.size()>90)n.resize(90);return n;}
std::wstring dialogFile(bool save,const wchar_t* filter,const wchar_t* extension,const std::wstring& initial){
    std::vector<wchar_t> path(32768,0);wcsncpy(path.data(),initial.c_str(),path.size()-1);OPENFILENAMEW o{};o.lStructSize=sizeof(o);o.hwndOwner=win;o.lpstrFilter=filter;o.lpstrFile=path.data();o.nMaxFile=path.size();o.lpstrDefExt=extension;o.Flags=OFN_EXPLORER|OFN_NOCHANGEDIR|OFN_PATHMUSTEXIST|(save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST);o.lpstrTitle=save?L"Сохранение файла":L"Открытие проекта";
    if(save?GetSaveFileNameW(&o):GetOpenFileNameW(&o))return path.data();
    if(CommDlgExtendedError()) error(L"Не удалось открыть окно выбора файла.");
    return{};
}
void makeFonts(){for(auto f:{font,smallFont,boldFont,titleFont,headingFont})if(f)DeleteObject(f);auto make=[](int size,int weight){return CreateFontW(-S(size),0,0,0,weight,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH|FF_DONTCARE,L"Segoe UI");};font=make(14,FW_NORMAL);smallFont=make(12,FW_NORMAL);boldFont=make(14,FW_SEMIBOLD);titleFont=make(25,FW_SEMIBOLD);headingFont=make(19,FW_SEMIBOLD);}
void setFont(HWND h,HFONT f=nullptr){SendMessageW(h,WM_SETFONT,(WPARAM)(f?f:font),TRUE);}
void status(const std::wstring& s){statusText=s;if(win){RECT r;GetClientRect(win,&r);r.left=S(side);r.top=r.bottom-S(36);InvalidateRect(win,&r,FALSE);}}
void refreshTitle(){if(!win)return;std::wstring s=wide(project.name)+(dirty?L" *":L"")+L" — Редактор вопросов";SetWindowTextW(win,s.c_str());RECT r;GetClientRect(win,&r);r.left=S(side);r.bottom=S(86);InvalidateRect(win,&r,FALSE);}
void collect();void buildForm(bool reset=false);void refreshList(bool reset=false);void layout();
void markDirty(){if(loading)return;dirty=true;refreshTitle();SetTimer(win,TIMER_REFRESH,350,nullptr);}
Question* current(){return active>=0&&active<(int)project.questions.size()?&project.questions[active]:nullptr;}
HWND button(HWND parent,int id,const wchar_t* caption){HWND h=CreateWindowExW(0,L"BUTTON",caption,WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW,0,0,10,10,parent,(HMENU)(INT_PTR)id,instance,nullptr);setFont(h,boldFont);return h;}
HWND baseControl(const wchar_t* cls,const std::wstring& caption,DWORD style,int x,int y,int w,int hgt,DWORD ex=0){
    HWND h=CreateWindowExW(ex,cls,caption.c_str(),WS_CHILD|WS_VISIBLE|style,0,0,1,1,form,(HMENU)(INT_PTR)nextId++,instance,nullptr);setFont(h);placements.push_back({h,x,y,w,hgt});return h;
}
HWND label(const std::wstring& caption,int x,int y,int w,int hgt=20,bool bold=false){auto h=baseControl(L"STATIC",caption,SS_LEFT|SS_NOPREFIX,x,y,w,hgt);setFont(h,bold?boldFont:font);return h;}
HWND field(const std::string& key,const std::wstring& caption,int x,int y,int w,int hgt=32,bool multi=false,const std::string& fallback="",const std::wstring& placeholder=L""){
    label(caption,x,y,w);auto q=current();std::string val;
    if(q){if(key.rfind("$",0)==0)val=q->param(key.substr(1),fallback);else val=get(q->f,key,fallback);}
    HWND h=baseControl(L"EDIT",wide(val),WS_TABSTOP|ES_LEFT|ES_AUTOVSCROLL|(multi?ES_MULTILINE|ES_WANTRETURN|WS_VSCROLL:ES_AUTOHSCROLL),x,y+25,w,hgt,WS_EX_CLIENTEDGE);
    SendMessageW(h,EM_SETLIMITTEXT,30000,0);SendMessageW(h,EM_SETMARGINS,EC_LEFTMARGIN|EC_RIGHTMARGIN,MAKELPARAM(S(7),S(7)));if(!placeholder.empty())SendMessageW(h,EM_SETCUEBANNER,TRUE,(LPARAM)placeholder.c_str());bindings.push_back({h,key.rfind("$",0)==0?"param":"field",key.rfind("$",0)==0?key.substr(1):key});return h;
}
HWND check(const std::wstring& caption,int x,int y,int w,bool checked,const std::string& kind,int index=0,bool radio=false){auto h=baseControl(L"BUTTON",caption,WS_TABSTOP|(radio?BS_AUTORADIOBUTTON:BS_AUTOCHECKBOX),x,y,w,26);SendMessageW(h,BM_SETCHECK,checked?BST_CHECKED:BST_UNCHECKED,0);bindings.push_back({h,kind,"",index});return h;}
HWND dynButton(const std::wstring& caption,int x,int y,int w,const std::string& action,int index=0){int id=nextId++;auto h=button(form,id,caption.c_str());placements.push_back({h,x,y,w,32});actions[id]={action,index};return h;}
HWND combo(const std::wstring& caption,const std::vector<std::string>& labels,const std::vector<std::string>& codes,const std::string& selected,const std::string& key,int x,int y,int w){
    label(caption,x,y,w);auto h=baseControl(WC_COMBOBOXW,L"",WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,x,y+25,w,32);int sel=0;for(size_t i=0;i<labels.size();i++){auto s=wide(labels[i]);SendMessageW(h,CB_ADDSTRING,0,(LPARAM)s.c_str());if(codes[i]==selected)sel=i;}SendMessageW(h,CB_SETCURSEL,sel,0);SendMessageW(h,CB_SETMINVISIBLE,9,0);bindings.push_back({h,"combo",key,0,codes});return h;
}
void positionForm(){RECT r;GetClientRect(form,&r);int max=std::max(0,S(contentHeight)-(int)r.bottom);scrollY=std::clamp(scrollY,0,max);SCROLLINFO si{sizeof(si),SIF_RANGE|SIF_PAGE|SIF_POS,0,S(contentHeight)-1,(UINT)r.bottom,scrollY,0};SetScrollInfo(form,SB_VERT,&si,TRUE);for(const auto& p:placements){wchar_t cls[32]{};GetClassNameW(p.h,cls,32);int height=wcscmp(cls,L"ComboBox")==0?std::max(300,p.hgt):p.hgt;MoveWindow(p.h,S(p.x),S(p.y)-scrollY,S(p.w),S(height),TRUE);}InvalidateRect(form,nullptr,FALSE);}
void ensureVisible(HWND h){if(!h||GetParent(h)!=form)return;RECT r,fr;GetWindowRect(h,&r);MapWindowPoints(nullptr,form,(POINT*)&r,2);GetClientRect(form,&fr);int old=scrollY;if(r.top<S(10))scrollY+=r.top-S(10);else if(r.bottom>fr.bottom-S(12))scrollY+=r.bottom-fr.bottom+S(12);if(old!=scrollY)positionForm();}
void collect(){
    if(loading)return;
    if(nameEdit)project.name=editText(nameEdit);
    auto q=current();if(!q)return;
    for(const auto& b:bindings){
        if(!IsWindow(b.h))continue;
        if(b.kind=="field")q->f[b.key]=editText(b.h);
        else if(b.kind=="param")q->setParam(b.key,editText(b.h));
        else if(b.kind=="choiceText"&&b.index<(int)q->choices.size())q->choices[b.index].text=editText(b.h);
        else if(b.kind=="choiceWeight"&&b.index<(int)q->choices.size())q->choices[b.index].weight=editText(b.h);
        else if(b.kind=="choiceCheck"&&b.index<(int)q->choices.size())q->choices[b.index].correct=SendMessageW(b.h,BM_GETCHECK,0,0)==BST_CHECKED;
        else if(b.kind=="pairLeft"&&b.index<(int)q->pairs.size())q->pairs[b.index].left=editText(b.h);
        else if(b.kind=="pairRight"&&b.index<(int)q->pairs.size())q->pairs[b.index].right=editText(b.h);
        else if(b.kind=="answers")q->answers=split(editText(b.h),'\n');
        else if(b.kind=="items")q->items=split(editText(b.h),'\n');
        else if(b.kind=="required")q->required=SendMessageW(b.h,BM_GETCHECK,0,0)==BST_CHECKED;
        else if(b.kind=="hide")q->hidePoints=SendMessageW(b.h,BM_GETCHECK,0,0)==BST_CHECKED;
        else if(b.kind=="boolTrue")q->booleanAnswer=SendMessageW(b.h,BM_GETCHECK,0,0)==BST_CHECKED;
        else if(b.kind=="combo"){int i=SendMessageW(b.h,CB_GETCURSEL,0,0);if(i>=0&&i<(int)b.codes.size())q->setParam(b.key,b.codes[i]);}
    }
}
std::wstring extraHint(const std::string& t){
    if(t=="text")return L"match=exact / contains_any / contains_all / fuzzy / regex; typo=1; case_sensitive=0";
    if(t=="slider")return L"min=0; max=100; step=1 — эти значения также доступны на вкладке «Ответы».";
    if(t=="fill_blank")return L"mode=input / dropdown / word_bank; distractors=слово1,слово2; case_sensitive=0";
    if(t=="dictation")return L"audio_url=https://…; scoring=proportional / all_or_nothing; mistakes=0";
    if(t=="essay")return L"min_words=50; max_words=250; keywords=сила|движение; min_keywords=1";
    if(t=="word_scramble")return L"extra_letters=АБ; case_sensitive=0";
    return L"shuffle=1 — перемешивать варианты; shuffle=0 — сохранить порядок.";
}
void buildForm(bool reset){
    if(!form)return;
    loading=true;
    for(const auto& p:placements) DestroyWindow(p.h);
    placements.clear();bindings.clear();actions.clear();nextId=2000;if(reset)scrollY=0;
    RECT rect;GetClientRect(form,&rect);int w=MulDiv(rect.right,96,dpi)-48;w=std::max(w,560);auto q=current();
    if(!q){label(L"Начните новый набор",28,28,w,32,true);label(L"Нажмите «Добавить вопрос» слева.",28,76,w,54);contentHeight=180;positionForm();loading=false;return;}
    auto type=q->type();label(L"ВОПРОС "+std::to_wstring(active+1),24,20,w-175,30,true);
    auto h=button(form,ID_CURRENTEXAMPLE,L"Пример вопроса");placements.push_back({h,24+w-174,16,174,30});
    int typeW=w-232;label(L"Тип задания",24,62,typeW);auto ct=baseControl(WC_COMBOBOXW,L"",WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL,24,87,typeW,32);SetWindowLongPtrW(ct,GWLP_ID,ID_TYPE);int ti=0;for(size_t i=0;i<typeLabels.size();i++){auto s=wide(typeLabels[i]);SendMessageW(ct,CB_ADDSTRING,0,(LPARAM)s.c_str());if(typeCodes[i]==type)ti=i;}SendMessageW(ct,CB_SETCURSEL,ti,0);SendMessageW(ct,CB_SETMINVISIBLE,13,0);
    field("points",L"Баллы",24+typeW+20,62,96);field("penalty",L"Штраф",24+typeW+136,62,96);
    field("title",L"Текст вопроса *",24,137,w,80,true,"",L"Напишите формулировку задания");
    int groupW=w/2;field("group_name",L"Раздел / тема",24,252,groupW,30,false,"",L"Например, Часть 1. Математика");check(L"Обязательный вопрос",24+groupW+24,279,w-groupW-24,q->required,"required");
    check(L"Скрыть баллы по этому вопросу в тесте",24,320,w,q->hidePoints,"hide");
    const wchar_t* captions[]={L"Ответы",L"Дополнительно",L"Предпросмотр"};int tx=24;for(int i=0;i<3;i++){auto b=button(form,ID_TAB0+i,captions[i]);int bw=i==0?112:162;placements.push_back({b,tx,365,bw,35});tx+=bw+8;}
    int y=425;
    if(tab==0){
        if(isChoice(type)){
            label(type=="multi"?L"Отметьте все правильные ответы слева.":L"Отметьте один правильный ответ слева.",24,y,w,24);y+=38;
            label(L"Верный",24,y,62);label(L"Вариант ответа",92,y,w-250);label(L"Балл за пункт¹",24+w-166,y,132);y+=27;
            for(size_t i=0;i<q->choices.size();i++){
                check(L"",35,y+2,32,q->choices[i].correct,"choiceCheck",i,type!="multi");
                auto e=baseControl(L"EDIT",wide(q->choices[i].text),WS_TABSTOP|ES_AUTOHSCROLL,92,y,w-258,32,WS_EX_CLIENTEDGE);SendMessageW(e,EM_SETMARGINS,EC_LEFTMARGIN|EC_RIGHTMARGIN,MAKELPARAM(S(7),S(7)));SendMessageW(e,EM_SETLIMITTEXT,2000,0);bindings.push_back({e,"choiceText","",(int)i});
                auto b=baseControl(L"EDIT",wide(q->choices[i].weight),WS_TABSTOP|ES_AUTOHSCROLL,24+w-166,y,110,32,WS_EX_CLIENTEDGE);SendMessageW(b,EM_SETCUEBANNER,TRUE,(LPARAM)L"необяз.");bindings.push_back({b,"choiceWeight","",(int)i});dynButton(L"×",24+w-40,y,40,"removeChoice",i);y+=42;
            }
            dynButton(L"+ Вариант ответа",24,y+4,178,"addChoice");y+=50;label(L"¹ Можно оставить пустым. Общий балл за вопрос задаётся выше.",24,y,w,26);y+=48;
        }else if(type=="boolean"){
            label(L"Какой ответ считается правильным?",24,y,w,26,true);y+=38;check(L"Верно / Да",24,y,200,q->booleanAnswer,"boolTrue",0,true);check(L"Неверно / Нет",250,y,250,!q->booleanAnswer,"boolFalse",0,true);y+=58;
        }else if(type=="number"||type=="slider"){
            field("target_value",L"Правильное число",24,y,(w-24)/2);field("tolerance",L"Погрешность ±",24+(w+24)/2,y,(w-24)/2);y+=84;
            label(L"Допускается десятичная точка или запятая. Погрешность 0 — точное совпадение.",24,y,w,40);y+=58;
            if(type=="slider"){int cw=(w-32)/3;field("$min",L"Минимум",24,y,cw,32,false,"0");field("$max",L"Максимум",24+cw+16,y,cw,32,false,"100");field("$step",L"Шаг",24+2*(cw+16),y,cw,32,false,"1");y+=86;}
        }else if(type=="text"||type=="word_scramble"||type=="ordering"){
            std::wstring cap=type=="ordering"?L"Элементы в правильном порядке — каждый с новой строки":type=="word_scramble"?L"Слово и допустимые варианты — каждый с новой строки":L"Допустимые ответы — каждый с новой строки";
            label(cap,24,y,w,25,true);auto e=baseControl(L"EDIT",wide(join(type=="ordering"?q->items:q->answers,"\r\n")),WS_TABSTOP|ES_MULTILINE|ES_AUTOVSCROLL|ES_WANTRETURN|WS_VSCROLL,24,y+32,w,136,WS_EX_CLIENTEDGE);SendMessageW(e,EM_SETLIMITTEXT,30000,0);bindings.push_back({e,type=="ordering"?"items":"answers",""});y+=190;
            if(type=="text"){combo(L"Как проверять текст",{"Точное совпадение (без учёта регистра)","Содержит любой ответ","Содержит все ответы","С допуском опечаток","Регулярное выражение"},{"exact","contains_any","contains_all","fuzzy","regex"},q->param("match","exact"),"match",24,y,w);y+=85;}
            if(type=="word_scramble"){field("$extra_letters",L"Дополнительные буквы-обманки (необязательно)",24,y,w);y+=85;}
        }else if(type=="matching"){
            label(L"Введите правильные пары. В тесте правая колонка будет перемешана.",24,y,w,40);y+=52;int cw=(w-76)/2;label(L"Левая часть",24,y,cw);label(L"Соответствует",24+cw+16,y,cw);y+=28;
            for(size_t i=0;i<q->pairs.size();i++){auto a=baseControl(L"EDIT",wide(q->pairs[i].left),WS_TABSTOP|ES_AUTOHSCROLL,24,y,cw,32,WS_EX_CLIENTEDGE);bindings.push_back({a,"pairLeft","",(int)i});auto b=baseControl(L"EDIT",wide(q->pairs[i].right),WS_TABSTOP|ES_AUTOHSCROLL,24+cw+16,y,cw,32,WS_EX_CLIENTEDGE);bindings.push_back({b,"pairRight","",(int)i});dynButton(L"×",24+w-40,y,40,"removePair",i);y+=42;}
            dynButton(L"+ Пара соответствий",24,y+4,210,"addPair");y+=68;
        }else if(type=="fill_blank"||type=="dictation"){
            label(L"Текст задания с пропусками",24,y,w,24,true);y+=31;
            label(type=="dictation"?L"Например: Вставьте букву: со{=л|лл}нце. Первый вариант после = — верный.":L"В фигурных скобках укажите ответ: Столица — {Москва|москва}.",24,y,w,44);y+=53;
            auto e=baseControl(L"EDIT",wide(get(q->f,"template")),WS_TABSTOP|ES_MULTILINE|ES_WANTRETURN|ES_AUTOVSCROLL|WS_VSCROLL,24,y,w,132,WS_EX_CLIENTEDGE);SendMessageW(e,EM_SETLIMITTEXT,30000,0);bindings.push_back({e,"field","template"});y+=154;
            if(type=="fill_blank"){combo(L"Способ заполнения",{"Ввод с клавиатуры","Выбор из списка","Банк слов"},{"input","dropdown","word_bank"},q->param("mode","input"),"mode",24,y,w);y+=86;}
            else{field("$audio_url",L"Ссылка на аудио (необязательно)",24,y,w,32,false,"",L"https://site.ru/audio.mp3");y+=85;field("$mistakes",L"Допустимое число ошибок",24,y,260,32,false,"0");y+=85;}
        }else if(type=="essay"){
            label(L"Участник введёт развёрнутый ответ. Его можно оценить вручную в плагине.",24,y,w,44);y+=58;field("$min_words",L"Минимум слов",24,y,(w-24)/2,32,false,"0");field("$max_words",L"Максимум слов (0 — без ограничения)",24+(w+24)/2,y,(w-24)/2,32,false,"0");y+=86;label(L"Для автоматической проверки ключевых слов используйте доп. параметры.",24,y,w,44);y+=58;
        }
        field("explanation",L"Пояснение / разбор (после ответа)",24,y,w,90,true,"",L"Необязательно. Объясните решение для участника и протокола.");y+=139;
    }else if(tab==1){
        field("image_url",L"Изображение к заданию — ссылка",24,y,w,32,false,"",L"https://site.ru/uploads/image.png");y+=80;label(L"Локальные изображения не встраиваются в импорт. Загрузите картинку на сайт и укажите доступную ссылку.",24,y,w,46);y+=62;
        field("content",L"Дополнительный текст под вопросом (можно HTML)",24,y,w,125,true);y+=177;
        field("shared_text_id",L"ID общего текста / кейса (необязательно)",24,y,w);y+=82;label(L"Общий текст с этим ID должен уже существовать в олимпиаде на сайте.",24,y,w,42);y+=54;
        field("extra",L"Другие параметры: ключ=значение; ключ2=значение2",24,y,w,86,true);y+=136;
        label(extraHint(type),24,y,w,68);y+=79;label(L"Видимость баллов всегда берётся из галочки выше. Параметры show_points и hide_points здесь переопределяются при экспорте.",24,y,w,64);y+=80;
    }else{
        label(L"ПРЕДПРОСМОТР ДЛЯ УЧАСТНИКА",24,y,w,24,true);y+=36;label(L"Ключи ответов и пояснение здесь не показываются. Оформление на сайте зависит от темы олимпиады.",24,y,w,46);y+=64;
        auto previewTitle=get(q->f,"title"); if(type=="fill_blank"||type=="dictation") previewTitle=std::regex_replace(previewTitle,std::regex(R"(\{[^}]*\})"),"[________]"); label(wide(previewTitle.empty()?"Текст вопроса пока не заполнен":previewTitle),24,y,w,90,true);y+=108;
        if(!q->hidePoints){label(L"Баллов за вопрос: "+wide(get(q->f,"points")),24,y,w,25);y+=40;}
        if(isChoice(type)){for(const auto& c:q->choices){label(std::wstring(type=="multi"?L"□  ":L"○  ")+wide(c.text),24,y,w,36);y+=43;}}
        else if(type=="boolean"){label(L"○  Верно / Да     ○  Неверно / Нет",24,y,w,36);y+=52;}
        else if(type=="matching"){for(const auto& a:q->pairs){label(wide(a.left)+L"     →     [выбрать соответствие]",24,y,w,38);y+=45;}}
        else if(type=="ordering"){label(L"[Элементы для расположения в правильном порядке]",24,y,w,44);y+=59;}
        else if(type=="fill_blank"||type=="dictation"){std::string p=std::regex_replace(get(q->f,"template"),std::regex(R"(\{[^}]*\})"),"[________]");label(wide(p),24,y,w,160);y+=180;}
        else if(type=="essay"){label(L"[Поле для развёрнутого ответа участника]",24,y,w,110);y+=128;}
        else if(type=="slider"){label(L"[Шкала от "+wide(q->param("min","0"))+L" до "+wide(q->param("max","100"))+L"]",24,y,w,65);y+=83;}
        else{label(L"[Поле для ответа участника]",24,y,w,55);y+=70;}
        if(!get(q->f,"image_url").empty()){label(L"Изображение будет загружено по указанной ссылке на сайте.",24,y,w,44);y+=55;}
    }
    contentHeight=y+28;positionForm();loading=false;
}
void refreshList(bool reset){if(!list)return;loading=true;int top=SendMessageW(list,LB_GETTOPINDEX,0,0);int count=SendMessageW(list,LB_GETCOUNT,0,0);if(count!=(int)project.questions.size()||reset){SendMessageW(list,WM_SETREDRAW,FALSE,0);SendMessageW(list,LB_RESETCONTENT,0,0);for(size_t i=0;i<project.questions.size();i++)SendMessageW(list,LB_ADDSTRING,0,(LPARAM)L" ");SendMessageW(list,WM_SETREDRAW,TRUE,0);}SendMessageW(list,LB_SETCURSEL,active,0);if(!reset&&top>=0)SendMessageW(list,LB_SETTOPINDEX,top,0);InvalidateRect(list,nullptr,FALSE);for(int id:{ID_COPY,ID_DELETE,ID_UP,ID_DOWN})if(controls.count(id))EnableWindow(controls[id],current()!=nullptr);loading=false;refreshTitle();RECT countRect={0,S(120),S(side),S(151)};InvalidateRect(win,&countRect,FALSE);}
void drawText(HDC dc,const std::wstring& s,RECT r,HFONT f,COLORREF color,UINT flags=DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS){SetBkMode(dc,TRANSPARENT);SetTextColor(dc,color);auto old=SelectObject(dc,f);DrawTextW(dc,s.c_str(),s.size(),&r,flags|DT_NOPREFIX);SelectObject(dc,old);}
void roundBox(HDC dc,RECT r,COLORREF fill,COLORREF border,int radius){auto b=CreateSolidBrush(fill); auto p=CreatePen(PS_SOLID,1,border);auto ob=SelectObject(dc,b),op=SelectObject(dc,p);RoundRect(dc,r.left,r.top,r.right,r.bottom,S(radius),S(radius));SelectObject(dc,ob);SelectObject(dc,op);DeleteObject(b);DeleteObject(p);}
bool drawItem(DRAWITEMSTRUCT* d){
    if(d->CtlID==ID_LIST){if(d->itemID==(UINT)-1||d->itemID>=project.questions.size())return true;const auto& q=project.questions[d->itemID];RECT r=d->rcItem;auto b=CreateSolidBrush(NAV);FillRect(d->hDC,&r,b);DeleteObject(b);RECT box=r;box.left+=S(10);box.right-=S(10);box.top+=S(3);box.bottom-=S(3);bool selected=d->itemState&ODS_SELECTED;if(selected)roundBox(d->hDC,box,NAVSEL,NAVSEL,10);RECT n=box;n.left+=S(10);n.right=n.left+S(32);drawText(d->hDC,std::to_wstring(d->itemID+1),n,boldFont,selected?RGB(130,221,199):NAVMUTED);RECT t=box;t.left+=S(48);t.right-=S(10);t.top+=S(8);t.bottom=t.top+S(23);auto title=get(q.f,"title");drawText(d->hDC,wide(title.empty()?"Новый вопрос":title),t,boldFont,WHITE);t.top+=S(26);t.bottom=t.top+S(18);drawText(d->hDC,wide(typeLabel(q.type()))+L"  ·  "+wide(get(q.f,"points"))+L" б.",t,smallFont,NAVMUTED);if(d->itemState&ODS_FOCUS)DrawFocusRect(d->hDC,&box);return true;}
    if(d->CtlType==ODT_BUTTON){bool nav=d->CtlID==ID_ADD||d->CtlID==ID_COPY||d->CtlID==ID_DELETE||d->CtlID==ID_UP||d->CtlID==ID_DOWN;bool accent=d->CtlID==ID_EXPORT||d->CtlID==ID_ADD;bool istab=d->CtlID>=ID_TAB0&&d->CtlID<=ID_TAB2;bool selected=istab&&tab==int(d->CtlID-ID_TAB0);COLORREF parent=GetParent(d->hwndItem)==form?WHITE:nav?NAV:BG;HBRUSH bg=CreateSolidBrush(parent);FillRect(d->hDC,&d->rcItem,bg);DeleteObject(bg);COLORREF fill=accent?TEAL:nav?NAVSEL:selected?PALE:WHITE;COLORREF border=accent?TEAL:nav?NAVSEL:selected?RGB(166,214,201):LINE;if(d->itemState&ODS_SELECTED)fill=accent?RGB(13,99,89):PALE;roundBox(d->hDC,d->rcItem,fill,border,9);COLORREF color=accent||nav?WHITE:selected?TEAL:INK;if(d->itemState&ODS_DISABLED)color=MUTED;RECT r=d->rcItem;r.left+=S(5);r.right-=S(5);drawText(d->hDC,text(d->hwndItem),r,boldFont,color,DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);if(d->itemState&ODS_FOCUS){InflateRect(&r,-S(3),-S(5));DrawFocusRect(d->hDC,&r);}return true;}return false;
}
void layout(){if(!win)return;RECT r;GetClientRect(win,&r);int W=r.right,H=r.bottom;MoveWindow(nameEdit,S(side+28),S(18),std::max(S(180),W-S(side+166)),S(36),TRUE);MoveWindow(controls[ID_HELP],W-S(108),S(22),S(80),S(32),TRUE);int x=S(side+28);for(auto p:std::vector<std::pair<int,int>>{{ID_NEW,85},{ID_OPEN,100},{ID_SAVE,112}}){MoveWindow(controls[p.first],x,S(95),S(p.second),S(34),TRUE);x+=S(p.second+9);}MoveWindow(controls[ID_CHECK],W-S(299),S(95),S(118),S(34),TRUE);MoveWindow(controls[ID_EXPORT],W-S(170),S(95),S(142),S(34),TRUE);MoveWindow(list,0,S(151),S(side),std::max(20,H-S(320)),TRUE);MoveWindow(controls[ID_ADD],S(20),H-S(147),S(side-40),S(40),TRUE);int bx=S(20);for(auto p:std::vector<std::pair<int,int>>{{ID_COPY,68},{ID_DELETE,78},{ID_UP,32},{ID_DOWN,32}}){MoveWindow(controls[p.first],bx,H-S(94),S(p.second),S(32),TRUE);bx+=S(p.second+7);}MoveWindow(form,S(side+28),S(151),std::max(S(100),W-S(side+56)),std::max(S(100),H-S(196)),TRUE);buildForm(false);InvalidateRect(win,nullptr,TRUE);}
void removeRecovery(){if(!recoveryPath.empty())DeleteFileW(recoveryPath.c_str());}
void prepareRecovery(){PWSTR path=nullptr;if(SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData,0,nullptr,&path))){std::wstring folder=std::wstring(path)+L"\\WP Olympiad Question Studio";CoTaskMemFree(path);CreateDirectoryW(folder.c_str(),nullptr);recoveryPath=folder+L"\\recovery.wpoq";}}
bool save(bool as=false){collect();std::wstring path=projectPath;if(as||path.empty())path=dialogFile(true,L"Проект редактора (*.wpoq)\0*.wpoq\0\0",L"wpoq",projectPath.empty()?cleanName(project.name)+L".wpoq":projectPath);if(path.empty())return false;try{writeFile(path,projectText(project));projectPath=path;dirty=false;removeRecovery();refreshTitle();status(L"Проект сохранён: "+path);return true;}catch(const std::exception& e){error(wide(e.what()));return false;}}
bool discard(){collect();if(!dirty)return true;int a=MessageBoxW(win,L"В проекте есть несохранённые изменения.\n\nСохранить их перед продолжением?",L"Сохранение проекта",MB_YESNOCANCEL|MB_ICONQUESTION);if(a==IDCANCEL)return false;if(a==IDYES)return save();return true;}
void setProject(Project p,const std::wstring& path,bool modified){loading=true;project=std::move(p);projectPath=path;active=project.questions.empty()?-1:0;tab=0;dirty=modified;SetWindowTextW(nameEdit,wide(project.name).c_str());loading=false;refreshList(true);buildForm(true);refreshTitle();}
void openProject(const std::wstring& given=L""){auto path=given.empty()?dialogFile(false,L"Проект редактора (*.wpoq)\0*.wpoq\0\0",L"wpoq",L""):given;if(path.empty())return;try{auto p=readProject(readFile(path));if(!discard())return;removeRecovery();setProject(std::move(p),path,false);status(L"Открыт проект: "+path);}catch(const std::exception& e){error(wide(e.what()));}}
void reportIssues(const std::vector<Issue>& issues){if(issues.empty()){MessageBoxW(win,L"Все вопросы готовы к импорту.\n\nМожно экспортировать файл в Excel, CSV или JSON.",L"Проверка завершена",MB_OK|MB_ICONINFORMATION);return;}std::wstring s=L"Экспорт пока невозможен. Исправьте замечания:\n\n";size_t count=std::min<size_t>(issues.size(),10);for(size_t i=0;i<count;i++)s+=L"Вопрос "+std::to_wstring(issues[i].index+1)+L": "+wide(issues[i].message)+L"\n\n";if(count<issues.size())s+=L"И ещё замечаний: "+std::to_wstring(issues.size()-count)+L".\n";s+=L"\nОткрыт первый вопрос с ошибкой. Черновик можно сохранить в любом состоянии.";active=issues.front().index;tab=0;refreshList();buildForm(true);MessageBoxW(win,s.c_str(),L"Проверка вопросов",MB_OK|MB_ICONWARNING);}
void exportFile(int format){collect();auto issues=validate(project);if(!issues.empty()){reportIssues(issues);return;}const wchar_t* ext=format==ID_XLSX?L"xlsx":format==ID_CSV?L"csv":L"json";const wchar_t* filter=format==ID_XLSX?L"Книга Excel (*.xlsx)\0*.xlsx\0\0":format==ID_CSV?L"CSV UTF-8 (*.csv)\0*.csv\0\0":L"JSON (*.json)\0*.json\0\0";auto path=dialogFile(true,filter,ext,L"Вопросы_"+cleanName(project.name)+L"."+ext);if(path.empty())return;try{auto data=format==ID_XLSX?exportXlsx(project):format==ID_CSV?exportCsv(project):exportJson(project);writeFile(path,data);status(L"Экспортировано вопросов: "+std::to_wstring(project.questions.size())+L"  ·  "+path);MessageBoxW(win,(L"Файл для импорта создан:\n"+path+L"\n\nНа сайте откройте олимпиаду → Конструктор вопросов → Импорт вопросов.\nВыберите этот файл. Можно также сохранить его в подключённую сетевую папку.\n\nДля дальнейшего редактирования сохраните проект отдельно кнопкой «Сохранить» (.wpoq).").c_str(),L"Экспорт завершён",MB_OK|MB_ICONINFORMATION);}catch(const std::exception& e){error(wide(e.what()));}}
void exportMenu(){RECT r;GetWindowRect(controls[ID_EXPORT],&r);HMENU m=CreatePopupMenu();AppendMenuW(m,MF_STRING,ID_XLSX,L"Excel (.xlsx) — рекомендуется");AppendMenuW(m,MF_STRING,ID_CSV,L"CSV UTF-8 (.csv)");AppendMenuW(m,MF_STRING,ID_JSON,L"JSON (.json)");TrackPopupMenu(m,TPM_RIGHTALIGN|TPM_TOPALIGN,r.right,r.bottom+S(4),0,win,nullptr);DestroyMenu(m);}
void help(){MessageBoxW(win,L"РЕДАКТОР ВОПРОСОВ • WP OLYMPIAD 1.0\n\n1. Нажмите «Добавить вопрос» и выберите тип задания.\n2. Введите текст, ответы и баллы. Отметьте правильные варианты.\n3. «Сохранить» сохраняет редактируемый проект (.wpoq).\n4. «Проверить» находит пропуски и ошибки.\n5. «Экспорт» создаёт Excel / CSV / JSON для вашего плагина.\n\nГотовый файл: Конструктор вопросов → Импорт вопросов либо подключённая сетевая папка.\n\nCtrl+S — сохранить; Ctrl+Shift+S — сохранить как; Ctrl+O — открыть.\nCtrl+E — экспорт; F7 — проверка; Ctrl+D — копия вопроса.\nCtrl+Shift+N — добавить вопрос; Alt+↑/↓ — порядок в списке.\n\nПрограмма работает локально без интернета. Excel и WordPress на ПК не нужны.\nИзображения и аудио добавляются только по ссылкам, доступным сайту.\nАвтовосстановление черновика: каждые 8 секунд в профиле Windows.",L"Как пользоваться",MB_OK|MB_ICONINFORMATION);}
void addQuestion(const std::string& type){collect();if(project.questions.size()>=MAX_QUESTIONS){error(L"В одном проекте можно создать не больше 2000 вопросов.");return;}Question q;q.f["type"]=type;int pos=current()?active+1:project.questions.size();project.questions.insert(project.questions.begin()+pos,q);active=pos;tab=0;markDirty();refreshList();buildForm(true);SendMessageW(list,LB_SETTOPINDEX,std::max(0,active-3),0);status(L"Добавлен вопрос. Заполните формулировку и правильный ответ.");}
void addMenu(){RECT r;GetWindowRect(controls[ID_ADD],&r);HMENU m=CreatePopupMenu();for(size_t i=0;i<typeCodes.size();i++)AppendMenuW(m,MF_STRING,300+i,wide(typeLabels[i]).c_str());int id=TrackPopupMenu(m,TPM_RETURNCMD|TPM_LEFTALIGN|TPM_BOTTOMALIGN,r.left,r.top-S(4),0,win,nullptr);DestroyMenu(m);if(id>=300&&id<313)addQuestion(typeCodes[id-300]);}
void handleAction(const std::string& a,int index){collect();auto q=current();if(!q)return;if(a=="addChoice"){if(q->choices.size()>=200){error(L"Максимум 200 вариантов.");return;}q->choices.push_back({"",false,""});}else if(a=="removeChoice"&&index<(int)q->choices.size())q->choices.erase(q->choices.begin()+index);else if(a=="addPair"){if(q->pairs.size()>=200){error(L"Максимум 200 пар.");return;}q->pairs.push_back({"",""});}else if(a=="removePair"&&index<(int)q->pairs.size())q->pairs.erase(q->pairs.begin()+index);markDirty();buildForm(false);}
void command(int id,int notification,HWND source){
    if(loading)return;
    if(id==ID_LIST&&notification==LBN_SELCHANGE){int target=SendMessageW(list,LB_GETCURSEL,0,0);collect();active=target;buildForm(true);return;}
    if(id==ID_NAME&&notification==EN_CHANGE){project.name=editText(nameEdit);markDirty();return;}
    if(id==ID_TYPE&&notification==CBN_SELCHANGE){int i=SendMessageW(source,CB_GETCURSEL,0,0);collect();if(current()&&i>=0&&i<(int)typeCodes.size()){current()->f["type"]=typeCodes[i];markDirty();refreshList();buildForm(false);}return;}
    if(id>=ID_TAB0&&id<=ID_TAB2){collect();tab=id-ID_TAB0;buildForm(false);return;}
    if(source&&(notification==EN_SETFOCUS||notification==CBN_SETFOCUS))ensureVisible(source);
    if(source&&(notification==EN_CHANGE||notification==CBN_SELCHANGE||notification==BN_CLICKED)){
        for(const auto& b:bindings)if(b.h==source){if(b.kind=="choiceCheck"&&current()&&current()->type()!="multi")for(const auto& c:bindings)if(c.kind=="choiceCheck")SendMessageW(c.h,BM_SETCHECK,c.h==source?BST_CHECKED:BST_UNCHECKED,0);if(b.kind=="boolTrue"||b.kind=="boolFalse")for(const auto& c:bindings)if(c.kind=="boolTrue"||c.kind=="boolFalse")SendMessageW(c.h,BM_SETCHECK,c.h==source?BST_CHECKED:BST_UNCHECKED,0);markDirty();return;}
    }
    if(actions.count(id)){auto a=actions[id];handleAction(a.first,a.second);return;}
    switch(id){
        case ID_NEW:if(discard()){removeRecovery();setProject(Project{},L"",false);status(L"Создан новый набор вопросов.");}break;
        case ID_OPEN:openProject();break;
        case ID_SAVE:save();break;
        case ID_SAVEAS:save(true);break;
        case ID_EXPORT:exportMenu();break;
        case ID_XLSX:case ID_CSV:case ID_JSON:exportFile(id);break;
        case ID_CHECK:collect();reportIssues(validate(project));break;
        case ID_ADD:addMenu();break;
        case ID_HELP:help();break;
        case ID_ALLSAMPLES:if(discard()){removeRecovery();setProject(sampleProject(),L"",true);status(L"Загружены 13 примеров. Заменяйте тексты своими вопросами.");}break;
        case ID_CURRENTEXAMPLE:{collect();auto q=current();if(!q)break;if(!get(q->f,"title").empty()&&MessageBoxW(win,L"Заменить текущий вопрос примером этого типа?\nТекст, ответы и параметры текущего вопроса будут заменены.",L"Пример вопроса",MB_YESNO|MB_ICONQUESTION)!=IDYES)break;auto samples=sampleProject();for(auto& s:samples.questions)if(s.type()==q->type()){*q=std::move(s);break;}markDirty();refreshList();buildForm(false);break;}
        case ID_COPY:collect();if(current()){if(project.questions.size()>=MAX_QUESTIONS){error(L"Максимум 2000 вопросов.");break;}Question copy=*current();project.questions.insert(project.questions.begin()+active+1,copy);active++;markDirty();refreshList();buildForm(true);}break;
        case ID_DELETE:collect();if(current()&&MessageBoxW(win,L"Удалить выбранный вопрос из проекта?",L"Удаление вопроса",MB_YESNO|MB_ICONQUESTION)==IDYES){project.questions.erase(project.questions.begin()+active);active=std::min(active,(int)project.questions.size()-1);markDirty();refreshList();buildForm(true);}break;
        case ID_UP:case ID_DOWN:collect();if(current()){int other=active+(id==ID_UP?-1:1);if(other>=0&&other<(int)project.questions.size()){std::swap(project.questions[active],project.questions[other]);active=other;markDirty();refreshList();buildForm(true);}}break;
        case ID_EXIT:SendMessageW(win,WM_CLOSE,0,0);break;
    }
}
LRESULT CALLBACK FormProc(HWND h,UINT m,WPARAM w,LPARAM l){
    switch(m){
        case WM_COMMAND:return SendMessageW(win,m,w,l);
        case WM_DRAWITEM:return SendMessageW(win,m,w,l);
        case WM_CTLCOLORSTATIC:case WM_CTLCOLOREDIT:case WM_CTLCOLORBTN:{auto dc=(HDC)w;SetTextColor(dc,INK);SetBkColor(dc,WHITE);return(LRESULT)whiteBrush;}
        case WM_ERASEBKGND:{RECT r;GetClientRect(h,&r);FillRect((HDC)w,&r,whiteBrush);return 1;}
        case WM_VSCROLL:{SCROLLINFO si{sizeof(si),SIF_ALL};GetScrollInfo(h,SB_VERT,&si);switch(LOWORD(w)){case SB_LINEUP:scrollY-=S(38);break;case SB_LINEDOWN:scrollY+=S(38);break;case SB_PAGEUP:scrollY-=si.nPage-S(28);break;case SB_PAGEDOWN:scrollY+=si.nPage-S(28);break;case SB_THUMBTRACK:case SB_THUMBPOSITION:scrollY=si.nTrackPos;break;case SB_TOP:scrollY=0;break;case SB_BOTTOM:scrollY=S(contentHeight);break;}positionForm();return 0;}
        case WM_MOUSEWHEEL:scrollY-=GET_WHEEL_DELTA_WPARAM(w)*S(72)/WHEEL_DELTA;positionForm();return 0;
    }
    return DefWindowProcW(h,m,w,l);
}
LRESULT CALLBACK WndProc(HWND h,UINT m,WPARAM w,LPARAM l){
    try{switch(m){
        case WM_CREATE:{win=h;makeFonts();bgBrush=CreateSolidBrush(BG);whiteBrush=CreateSolidBrush(WHITE);navBrush=CreateSolidBrush(NAV);
            nameEdit=CreateWindowExW(0,L"EDIT",wide(project.name).c_str(),WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,0,0,10,10,h,(HMENU)ID_NAME,instance,nullptr);setFont(nameEdit,titleFont);SendMessageW(nameEdit,EM_SETLIMITTEXT,150,0);
            for(auto c:std::vector<std::pair<int,const wchar_t*>>{{ID_NEW,L"Новый"},{ID_OPEN,L"Открыть"},{ID_SAVE,L"Сохранить"},{ID_CHECK,L"Проверить"},{ID_EXPORT,L"Экспорт  ▾"},{ID_HELP,L"Помощь"},{ID_ADD,L"+  Добавить вопрос"},{ID_COPY,L"Копия"},{ID_DELETE,L"Удалить"},{ID_UP,L"↑"},{ID_DOWN,L"↓"}})controls[c.first]=button(h,c.first,c.second);
            list=CreateWindowExW(0,L"LISTBOX",L"",WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_VSCROLL|LBS_NOTIFY|LBS_OWNERDRAWFIXED|LBS_HASSTRINGS|LBS_NOINTEGRALHEIGHT,0,0,10,10,h,(HMENU)ID_LIST,instance,nullptr);SendMessageW(list,LB_SETITEMHEIGHT,0,S(73));SetWindowTheme(list,L"",L"");setFont(list);
            form=CreateWindowExW(WS_EX_CONTROLPARENT,L"WPOQuestionForm",L"",WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_CLIPCHILDREN,0,0,10,10,h,nullptr,instance,nullptr);
            HMENU menu=CreateMenu(),fileMenu=CreatePopupMenu(),questionMenu=CreatePopupMenu(),helpMenu=CreatePopupMenu();
            AppendMenuW(fileMenu,MF_STRING,ID_NEW,L"Новый проект\tCtrl+N");AppendMenuW(fileMenu,MF_STRING,ID_OPEN,L"Открыть проект…\tCtrl+O");AppendMenuW(fileMenu,MF_STRING,ID_SAVE,L"Сохранить\tCtrl+S");AppendMenuW(fileMenu,MF_STRING,ID_SAVEAS,L"Сохранить как…\tCtrl+Shift+S");AppendMenuW(fileMenu,MF_SEPARATOR,0,nullptr);AppendMenuW(fileMenu,MF_STRING,ID_XLSX,L"Экспорт Excel (.xlsx)…");AppendMenuW(fileMenu,MF_STRING,ID_CSV,L"Экспорт CSV (.csv)…");AppendMenuW(fileMenu,MF_STRING,ID_JSON,L"Экспорт JSON (.json)…");AppendMenuW(fileMenu,MF_SEPARATOR,0,nullptr);AppendMenuW(fileMenu,MF_STRING,ID_EXIT,L"Выход");
            AppendMenuW(questionMenu,MF_STRING,ID_ADD,L"Добавить…\tCtrl+Shift+N");AppendMenuW(questionMenu,MF_STRING,ID_COPY,L"Дублировать\tCtrl+D");AppendMenuW(questionMenu,MF_STRING,ID_DELETE,L"Удалить");AppendMenuW(questionMenu,MF_STRING,ID_CHECK,L"Проверить все вопросы\tF7");AppendMenuW(questionMenu,MF_SEPARATOR,0,nullptr);AppendMenuW(questionMenu,MF_STRING,ID_UP,L"Переместить выше");AppendMenuW(questionMenu,MF_STRING,ID_DOWN,L"Переместить ниже");
            AppendMenuW(helpMenu,MF_STRING,ID_HELP,L"Как пользоваться\tF1");AppendMenuW(helpMenu,MF_STRING,ID_ALLSAMPLES,L"Загрузить примеры — все 13 типов");AppendMenuW(menu,MF_POPUP,(UINT_PTR)fileMenu,L"Файл");AppendMenuW(menu,MF_POPUP,(UINT_PTR)questionMenu,L"Вопросы");AppendMenuW(menu,MF_POPUP,(UINT_PTR)helpMenu,L"Справка");SetMenu(h,menu);
            refreshList(true);prepareRecovery();SetTimer(h,TIMER_RECOVERY,8000,nullptr);return 0;}
        case WM_SIZE:if(form){collect();layout();}return 0;
        case WM_GETMINMAXINFO:{auto p=(MINMAXINFO*)l;p->ptMinTrackSize={S(960),S(570)};return 0;}
        case WM_COMMAND:command(LOWORD(w),HIWORD(w),(HWND)l);return 0;
        case WM_DRAWITEM:if(drawItem((DRAWITEMSTRUCT*)l))return TRUE;break;
        case WM_MEASUREITEM:if(((MEASUREITEMSTRUCT*)l)->CtlID==ID_LIST){((MEASUREITEMSTRUCT*)l)->itemHeight=S(73);return TRUE;}break;
        case WM_CTLCOLORLISTBOX:SetBkColor((HDC)w,NAV);SetTextColor((HDC)w,WHITE);return(LRESULT)navBrush;
        case WM_CTLCOLOREDIT:if((HWND)l==nameEdit){SetBkColor((HDC)w,BG);SetTextColor((HDC)w,INK);return(LRESULT)bgBrush;}break;
        case WM_TIMER:if(w==TIMER_REFRESH){KillTimer(h,TIMER_REFRESH);collect();refreshList();}else if(w==TIMER_RECOVERY&&dirty&&!recoveryPath.empty()){collect();try{auto j=projectJson(project);j["original_path"]=utf8(projectPath);auto recovery=j.dump(2)+"\n";if(recovery.size()>MAX_FILE)throw std::runtime_error("Project too large");writeFile(recoveryPath,recovery);status(L"Черновик для восстановления обновлён. Ctrl+S — сохранить проект.");}catch(...){status(L"Не удалось обновить автовосстановление. Сохраните проект кнопкой «Сохранить».");}}return 0;
        case WM_DPICHANGED:{collect();dpi=HIWORD(w);makeFonts();setFont(nameEdit,titleFont);for(auto c:controls)setFont(c.second,boldFont);SendMessageW(list,LB_SETITEMHEIGHT,0,S(73));auto r=(RECT*)l;SetWindowPos(h,nullptr,r->left,r->top,r->right-r->left,r->bottom-r->top,SWP_NOZORDER|SWP_NOACTIVATE);layout();return 0;}
        case WM_ERASEBKGND:return 1;
        case WM_PAINT:{PAINTSTRUCT ps;auto dc=BeginPaint(h,&ps);RECT r;GetClientRect(h,&r);FillRect(dc,&r,bgBrush);RECT left={0,0,S(side),r.bottom};FillRect(dc,&left,navBrush);DrawIconEx(dc,S(22),S(24),(HICON)LoadImageW(instance,MAKEINTRESOURCEW(1),IMAGE_ICON,S(46),S(46),LR_DEFAULTCOLOR|LR_SHARED),S(46),S(46),0,nullptr,DI_NORMAL);RECT brand={S(82),S(21),S(side-18),S(51)};drawText(dc,L"Редактор",brand,headingFont,WHITE);brand.top=S(49);brand.bottom=S(75);drawText(dc,L"вопросов",brand,headingFont,WHITE);RECT sub={S(24),S(89),S(side-18),S(112)};drawText(dc,L"WP OLYMPIAD  /  OFFLINE",sub,smallFont,NAVMUTED);RECT lab={S(24),S(125),S(side-20),S(145)};drawText(dc,L"ВОПРОСЫ   "+std::to_wstring(project.questions.size()),lab,smallFont,NAVMUTED);RECT foot={S(24),r.bottom-S(42),S(side-20),r.bottom-S(16)};drawText(dc,L"Локально. Без интернета.",foot,smallFont,NAVMUTED);long long total=0;for(const auto& q:project.questions)if(integer(get(q.f,"points")))total+=std::stoll(get(q.f,"points"));RECT summary={S(side+30),S(60),r.right-S(30),S(82)};drawText(dc,std::to_wstring(project.questions.size())+L" вопросов  ·  "+std::to_wstring(total)+L" баллов  ·  "+(dirty?L"Есть несохранённые изменения":projectPath.empty()?L"Новый проект":L"Проект сохранён"),summary,font,MUTED);RECT statusRect={S(side+30),r.bottom-S(31),r.right-S(20),r.bottom-S(8)};drawText(dc,statusText,statusRect,smallFont,MUTED);EndPaint(h,&ps);return 0;}
        case WM_CLOSE:if(!closing&&discard()){closing=true;removeRecovery();DestroyWindow(h);}return 0;
        case WM_DESTROY:KillTimer(h,TIMER_RECOVERY);KillTimer(h,TIMER_REFRESH);PostQuitMessage(0);return 0;
    }}catch(const std::exception& e){error(wide(e.what()));}catch(...){error(L"Не удалось выполнить действие. Сохраните проект и повторите попытку.");}
    return DefWindowProcW(h,m,w,l);
}
bool shortcut(MSG& m){if(m.message!=WM_KEYDOWN&&m.message!=WM_SYSKEYDOWN)return false;bool ctrl=GetKeyState(VK_CONTROL)<0,shift=GetKeyState(VK_SHIFT)<0,alt=GetKeyState(VK_MENU)<0;int id=0;if(ctrl){switch(m.wParam){case 'N':id=shift?ID_ADD:ID_NEW;break;case 'O':id=ID_OPEN;break;case 'S':id=shift?ID_SAVEAS:ID_SAVE;break;case 'E':id=ID_EXPORT;break;case 'D':id=ID_COPY;break;}}else if(m.wParam==VK_F7)id=ID_CHECK;else if(m.wParam==VK_F1)id=ID_HELP;else if(GetFocus()==list&&m.wParam==VK_DELETE)id=ID_DELETE;else if(alt&&GetFocus()==list&&m.wParam==VK_UP)id=ID_UP;else if(alt&&GetFocus()==list&&m.wParam==VK_DOWN)id=ID_DOWN;if(id){command(id,0,nullptr);return true;}return false;}
int smoke(const std::wstring& folder){try{CreateDirectoryW(folder.c_str(),nullptr);auto p=sampleProject();auto issues=validate(p);json result={{"questions",p.questions.size()},{"issues",json::array()},{"roundtrip",projectText(readProject(projectText(p)))==projectText(p)}};for(const auto& i:issues)result["issues"].push_back({{"question",i.index+1},{"message",i.message}});writeFile(folder+L"\\sample.wpoq",projectText(p));writeFile(folder+L"\\questions.xlsx",exportXlsx(p));writeFile(folder+L"\\questions.csv",exportCsv(p));writeFile(folder+L"\\questions.json",exportJson(p));writeFile(folder+L"\\result.json",result.dump(2));return issues.empty()&&result["roundtrip"].get<bool>()?0:1;}catch(...){return 2;}}
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,LPWSTR,int show){
    instance=h;int argc=0;LPWSTR* argv=CommandLineToArgvW(GetCommandLineW(),&argc);
    if(argc>=3&&std::wstring(argv[1])==L"--self-test"){int code=smoke(argv[2]);LocalFree(argv);return code;}
    bool demo=argc>=2&&std::wstring(argv[1])==L"--demo";std::wstring given=argc>=2&&!demo?argv[1]:L"";LocalFree(argv);
    HANDLE mutex=CreateMutexW(nullptr,FALSE,L"Local\\WPOlympiadQuestionStudio-v1");if(mutex&&GetLastError()==ERROR_ALREADY_EXISTS){MessageBoxW(nullptr,L"Редактор вопросов уже открыт.\nПереключитесь в его окно, чтобы продолжить работу.",L"Редактор вопросов",MB_OK|MB_ICONINFORMATION);CloseHandle(mutex);return 0;}
    CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);INITCOMMONCONTROLSEX cc{sizeof(cc),ICC_STANDARD_CLASSES|ICC_WIN95_CLASSES};InitCommonControlsEx(&cc);SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);dpi=GetDpiForSystem();if(demo)project=sampleProject();
    WNDCLASSEXW f{sizeof(f)};f.lpfnWndProc=FormProc;f.hInstance=h;f.lpszClassName=L"WPOQuestionForm";f.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassExW(&f);
    WNDCLASSEXW c{sizeof(c)};c.lpfnWndProc=WndProc;c.hInstance=h;c.lpszClassName=L"WPOQuestionStudio";c.hCursor=LoadCursor(nullptr,IDC_ARROW);c.hIcon=(HICON)LoadImageW(h,MAKEINTRESOURCEW(1),IMAGE_ICON,0,0,LR_DEFAULTSIZE);c.hIconSm=(HICON)LoadImageW(h,MAKEINTRESOURCEW(1),IMAGE_ICON,16,16,LR_DEFAULTCOLOR);RegisterClassExW(&c);
    RECT work;SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);int width=std::min(S(1280),(int)(work.right-work.left)),height=std::min(S(900),(int)(work.bottom-work.top));HWND window=CreateWindowExW(WS_EX_CONTROLPARENT,c.lpszClassName,L"Редактор вопросов — WP Olympiad",WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,work.left+(work.right-work.left-width)/2,work.top+(work.bottom-work.top-height)/2,width,height,nullptr,nullptr,h,nullptr);if(!window){if(mutex)CloseHandle(mutex);CoUninitialize();return 1;}
    ShowWindow(window,show);UpdateWindow(window);
    if(!given.empty())openProject(given);else if(!demo&&!recoveryPath.empty()&&GetFileAttributesW(recoveryPath.c_str())!=INVALID_FILE_ATTRIBUTES){if(MessageBoxW(win,L"Найден черновик после незавершённой работы.\n\nВосстановить вопросы?",L"Автовосстановление",MB_YESNO|MB_ICONQUESTION)==IDYES){try{auto data=readFile(recoveryPath);auto p=readProject(data);auto j=json::parse(data);setProject(p,wide(j.value("original_path",std::string{})),true);status(L"Черновик восстановлен. Сохраните проект кнопкой «Сохранить».");}catch(const std::exception& e){error(wide(e.what()));removeRecovery();}}else removeRecovery();}
    MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){try{if(shortcut(msg))continue;}catch(const std::exception& e){error(wide(e.what()));}if(!IsDialogMessageW(window,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}
    if(mutex) CloseHandle(mutex);
    CoUninitialize();return(int)msg.wParam;
}
