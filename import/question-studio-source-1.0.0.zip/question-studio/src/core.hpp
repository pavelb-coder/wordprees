// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <map>
#include <regex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "../vendor/json.hpp"

namespace studio {
using json = nlohmann::json;
using Row = std::map<std::string, std::string>;
constexpr size_t MAX_QUESTIONS = 2000;
constexpr size_t MAX_FILE = 24 * 1024 * 1024;
inline const std::vector<std::string> columns = {"type","title","points","penalty","group_name","choices","correct","target_value","tolerance","answers","explanation","is_required","content","image_url","shared_text_id","template","extra"};
inline const std::vector<std::string> typeCodes = {"single","multi","dropdown","boolean","number","text","matching","ordering","fill_blank","slider","word_scramble","dictation","essay"};
inline const std::vector<std::string> typeLabels = {"Один правильный ответ","Несколько правильных ответов","Выпадающий список","Верно / неверно","Числовой ответ","Краткий текстовый ответ","Соответствие","Последовательность","Заполнение пропусков","Шкала / ползунок","Составление слова","Диктант","Развёрнутый ответ"};
inline const std::vector<std::string> columnLabels = {"Тип задания","Текст вопроса","Баллы","Штраф","Раздел","Варианты / пары / элементы","Ключ ответа","Правильное число","Погрешность","Допустимые ответы","Пояснение","Обязательный","Дополнительный текст (HTML)","Изображение (URL)","Общий текст (ID)","Текст с пропусками","Дополнительные параметры"};
inline std::string trim(const std::string& s) {
    auto a = s.find_first_not_of(" \t\n\r");
    return a == std::string::npos ? "" : s.substr(a, s.find_last_not_of(" \t\n\r") - a + 1);
}
inline std::string get(const Row& r, const std::string& k, const std::string& fallback = "") {
    auto i = r.find(k); return i == r.end() ? fallback : i->second;
}
inline std::string scalar(const json& v) {
    if (v.is_string()) return v.get<std::string>();
    if (v.is_null()) return "";
    if (v.is_boolean()) return v.get<bool>() ? "1" : "0";
    if (v.is_number()) return v.dump();
    throw std::runtime_error("Некорректное значение поля в файле.");
}
inline std::vector<std::string> split(const std::string& s, char sep, bool skipEmpty = true) {
    std::vector<std::string> v; size_t start = 0;
    do {
        size_t end = s.find(sep, start);
        std::string part = trim(s.substr(start, end == std::string::npos ? end : end - start));
        if (!skipEmpty || !part.empty()) v.push_back(part);
        if (end == std::string::npos) break;
        start = end + 1;
    } while (start <= s.size());
    return v;
}
inline std::string join(const std::vector<std::string>& v, const std::string& sep) {
    std::string s; for (const auto& a : v) { if (!s.empty()) s += sep; s += a; } return s;
}
inline Row parseExtra(const std::string& raw) {
    Row out; auto text = raw; std::replace(text.begin(),text.end(),'\n',';');
    for (const auto& p : split(text, ';')) {
        size_t eq = p.find('=');
        if (eq != std::string::npos) {
            auto key=trim(p.substr(0,eq));
            for(auto& c:key) if(c>='A'&&c<='Z') c=char(c-'A'+'a');
            if(!out.count(key)) out[key] = trim(p.substr(eq + 1));
        }
    }
    return out;
}
inline std::string extraString(const Row& r) {
    std::vector<std::string> v;
    for (const auto& a : r) if (!a.first.empty()) v.push_back(a.first + "=" + a.second);
    return join(v, "; ");
}
inline bool truth(const std::string& raw) {
    auto s = trim(raw);
    return s == "1" || s == "true" || s == "yes" || s == "да" || s == "Да" || s == "верно" || s == "Верно" || s == "+";
}
inline bool integer(const std::string& s, int min = 0, int max = 1000000) {
    auto t = trim(s); if (t.empty() || t.size() > 10) return false;
    if (!std::all_of(t.begin(), t.end(), [](unsigned char c){ return c >= '0' && c <= '9'; })) return false;
    auto n = std::strtoll(t.c_str(), nullptr, 10); return n >= min && n <= max;
}
inline bool number(const std::string& s, double* value = nullptr) {
    auto t = trim(s); std::replace(t.begin(), t.end(), ',', '.');
    if (t.empty() || t.size() > 80) return false;
    if (!std::regex_match(t, std::regex(R"([+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?)"))) return false;
    char* end; double n = std::strtod(t.c_str(), &end);
    if (*end || !std::isfinite(n)) return false;
    if (value) *value = n;
    return true;
}
inline size_t textLength(const std::string& s) {
    return std::count_if(s.begin(), s.end(), [](unsigned char c){ return (c & 0xc0) != 0x80; });
}
inline std::string typeLabel(const std::string& t) {
    auto i = std::find(typeCodes.begin(), typeCodes.end(), t);
    return i == typeCodes.end() ? t : typeLabels[i - typeCodes.begin()];
}
inline bool isChoice(const std::string& t) { return t == "single" || t == "multi" || t == "dropdown"; }
struct Choice { std::string text; bool correct = false; std::string weight; };
struct Pair { std::string left, right; };
struct Question {
    Row f = {{"type","single"},{"title",""},{"points","1"},{"penalty","0"},{"group_name",""},{"target_value",""},{"tolerance","0"},{"explanation",""},{"content",""},{"image_url",""},{"shared_text_id",""},{"template",""},{"extra",""}};
    std::vector<Choice> choices = {{"",false,""},{"",false,""}};
    std::vector<Pair> pairs = {{"",""},{"",""}};
    std::vector<std::string> items, answers;
    bool required = true, hidePoints = true, booleanAnswer = true;
    std::string type() const { return get(f, "type", "single"); }
    void setParam(const std::string& key, const std::string& val) {
        Row p = parseExtra(get(f, "extra"));
        if (val.empty()) p.erase(key); else p[key] = val;
        f["extra"] = extraString(p);
    }
    std::string param(const std::string& key, const std::string& fallback = "") const { return get(parseExtra(get(f,"extra")), key, fallback); }
};
struct Project { std::string name = "Новый набор вопросов"; std::vector<Question> questions = {Question{}}; };

inline Question fromRow(const Row& row) {
    Question q;
    for (const auto& kv : row) if (q.f.count(kv.first)) q.f[kv.first] = kv.second;
    q.required = row.count("is_required") ? truth(get(row,"is_required")) : false;
    auto ex = parseExtra(get(row,"extra"));
    q.hidePoints = ex.count("show_points") ? !truth(ex["show_points"]) : ex.count("hide_points") ? truth(ex["hide_points"]) : true;
    ex.erase("show_points"); ex.erase("hide_points"); q.f["extra"] = extraString(ex);
    q.booleanAnswer = truth(get(row,"correct","1"));
    q.answers = split(get(row,"answers"), '|');
    q.items = split(get(row,"choices"), '|');
    if (isChoice(q.type())) {
        q.choices.clear(); int pos = 0;
        auto keys = split(get(row,"correct"), ',');
        for (auto text : split(get(row,"choices"), '|')) {
            ++pos; Choice c;
            size_t caret = text.rfind('^');
            if (caret != std::string::npos && integer(text.substr(caret+1))) { c.weight = text.substr(caret+1); text = trim(text.substr(0,caret)); }
            c.correct = !text.empty() && text[0] == '*';
            if (c.correct) text = trim(text.substr(1));
            c.text = text;
            if (std::find(keys.begin(),keys.end(),std::to_string(pos)) != keys.end() || std::find(keys.begin(),keys.end(),text) != keys.end()) c.correct = true;
            q.choices.push_back(c);
        }
    } else if (q.type() == "matching") {
        q.pairs.clear();
        for (const auto& text : split(get(row,"choices"), '|')) {
            size_t p = text.find("=>");
            if (p != std::string::npos) q.pairs.push_back({trim(text.substr(0,p)),trim(text.substr(p+2))});
        }
    }
    if ((q.type()=="fill_blank" || q.type()=="dictation") && trim(get(q.f,"template")).empty()) q.f["template"] = get(q.f,"title");
    return q;
}
inline std::string normalizeLines(const std::string& s) {
    std::string out; for(size_t i=0;i<s.size();i++){if(s[i]=='\r'){out+='\n';if(i+1<s.size()&&s[i+1]=='\n')i++;}else out+=s[i];}return out;
}
inline Row toRow(const Question& q) {
    Row r; for (const auto& k : columns) r[k] = trim(normalizeLines(get(q.f,k)));
    auto t = q.type();
    r["is_required"] = q.required ? "1" : "0";
    Row ex = parseExtra(get(q.f,"extra")); ex.erase("hide_points"); ex["show_points"] = q.hidePoints ? "0" : "1";
    r["extra"] = extraString(ex);
    if (isChoice(t)) {
        std::vector<std::string> v;
        for (const auto& c : q.choices) v.push_back(std::string(c.correct ? "*" : "") + trim(c.text) + (trim(c.weight).empty() ? "" : "^" + trim(c.weight)));
        r["choices"] = join(v," | ");
    } else if (t == "matching") {
        std::vector<std::string> v; for (const auto& p : q.pairs) v.push_back(trim(p.left)+" => "+trim(p.right)); r["choices"] = join(v," | ");
    } else if (t == "ordering") r["choices"] = join(q.items," | ");
    if (t == "text" || t == "word_scramble") r["answers"] = join(q.answers," | ");
    if (t == "boolean") r["correct"] = q.booleanAnswer ? "да" : "нет";
    return r;
}
inline json questionJson(const Question& q) {
    json choices = json::array(), pairs = json::array();
    for (const auto& c:q.choices) choices.push_back({{"text",c.text},{"correct",c.correct},{"weight",c.weight}});
    for (const auto& p:q.pairs) pairs.push_back({{"left",p.left},{"right",p.right}});
    return {{"fields",q.f},{"choices",choices},{"pairs",pairs},{"items",q.items},{"answers",q.answers},{"required",q.required},{"hide_points",q.hidePoints},{"boolean_answer",q.booleanAnswer}};
}
inline json projectJson(const Project& p) {
    json qs = json::array(); for (const auto& q:p.questions) qs.push_back(questionJson(q));
    return {{"format","wpo-question-studio-project"},{"version",1},{"name",p.name},{"questions",qs}};
}
inline std::string projectText(const Project& p) {
    auto s=projectJson(p).dump(2, ' ', false, json::error_handler_t::strict)+"\n";
    if(s.size()>MAX_FILE)throw std::runtime_error("Проект больше 24 МБ. Разделите вопросы на несколько проектов.");
    return s;
}
inline Question readProjectQuestion(const json& j) {
    if (!j.is_object() || !j.contains("fields") || !j["fields"].is_object()) throw std::runtime_error("Некорректная структура вопроса.");
    Question q;
    for (auto it=j["fields"].begin();it!=j["fields"].end();++it) if (q.f.count(it.key())) q.f[it.key()] = scalar(it.value());
    q.required=j.value("required",true); q.hidePoints=j.value("hide_points",true); q.booleanAnswer=j.value("boolean_answer",true);
    auto checkArray=[](const json& a, size_t limit) { if (!a.is_array() || a.size()>limit) throw std::runtime_error("Слишком много элементов в вопросе."); };
    if (j.contains("choices")) { checkArray(j["choices"],200); q.choices.clear(); for(const auto& c:j["choices"]) q.choices.push_back({c.at("text").get<std::string>(),c.value("correct",false),c.value("weight",std::string{})}); }
    if (j.contains("pairs")) { checkArray(j["pairs"],200); q.pairs.clear(); for(const auto& a:j["pairs"]) q.pairs.push_back({a.at("left").get<std::string>(),a.at("right").get<std::string>()}); }
    if (j.contains("items")) { checkArray(j["items"],30000); q.items=j["items"].get<std::vector<std::string>>(); }
    if (j.contains("answers")) { checkArray(j["answers"],30000); q.answers=j["answers"].get<std::vector<std::string>>(); }
    if (std::find(typeCodes.begin(),typeCodes.end(),q.type())==typeCodes.end()) throw std::runtime_error("Неизвестный тип вопроса: "+q.type());
    return q;
}
inline Project readProject(std::string text) {
    if (text.size()>MAX_FILE) throw std::runtime_error("Файл больше 24 МБ.");
    if (text.compare(0,3,"\xef\xbb\xbf")==0) text.erase(0,3);
    auto j=json::parse(text);
    if (!j.is_object() || j.value("format",std::string{})!="wpo-question-studio-project" || j.value("version",0)!=1) throw std::runtime_error("Это не проект редактора. Откройте файл .wpoq, сохранённый этой программой.");
    if (!j.contains("questions") || !j["questions"].is_array() || j["questions"].size()>MAX_QUESTIONS) throw std::runtime_error("В проекте должно быть не больше 2000 вопросов.");
    Project p; p.name=j.value("name",std::string{"Набор вопросов"}); p.questions.clear();
    for (const auto& a:j["questions"]) p.questions.push_back(readProjectQuestion(a));
    return p;
}
struct Issue { size_t index; std::string message; };
inline std::vector<Issue> validate(const Project& p) {
    std::vector<Issue> out;
    if (p.questions.empty()) out.push_back({0,"Добавьте хотя бы один вопрос."});
    if (p.questions.size()>MAX_QUESTIONS) out.push_back({0,"В одном файле допускается не более 2000 вопросов."});
    for (size_t i=0;i<p.questions.size();++i) {
        const auto& q=p.questions[i]; auto t=q.type();
        auto bad=[&](const std::string& s){out.push_back({i,s});};
        if (trim(get(q.f,"title")).empty()) bad("Заполните текст вопроса.");
        if (std::find(typeCodes.begin(),typeCodes.end(),t)==typeCodes.end()) bad("Неизвестный тип задания.");
        if (!integer(get(q.f,"points"))) bad("Баллы: укажите целое число от 0 до 1 000 000.");
        if (!integer(get(q.f,"penalty"))) bad("Штраф: укажите целое число от 0 до 1 000 000.");
        for (const auto& a:q.f) {
            if (textLength(a.second)>30000) bad("Поле «"+a.first+"» слишком длинное (не более 30 000 символов).");
            if (std::any_of(a.second.begin(),a.second.end(),[](unsigned char c){return c<32 && c!=9 && c!=10 && c!=13;})) bad("Поле «"+a.first+"» содержит недопустимый управляющий символ.");
        }
        auto plain=[&](const std::string& s,const std::string& field) {
            if (trim(s).empty()) bad(field+": есть пустой элемент.");
            if (s.find('|')!=std::string::npos) bad(field+": символ | служит разделителем; замените его на /.");
            if (s.find('\n')!=std::string::npos || s.find('\r')!=std::string::npos) bad(field+": один элемент должен занимать одну строку.");
            if ((t=="matching"||t=="ordering") && std::regex_search(trim(s),std::regex(R"(\^-?[0-9]+(?:[.,][0-9]+)?$)"))) bad(field+": запись ^число в конце служит служебной разметкой баллов.");
        };
        if (isChoice(t)) {
            if (q.choices.size()<2 || q.choices.size()>200) bad("Нужно от 2 до 200 вариантов ответа.");
            int correct=0;
            for (const auto& c:q.choices) {
                plain(c.text,"Варианты"); auto s=trim(c.text);
                if (!s.empty() && s[0]=='*') bad("Не начинайте текст варианта со звёздочки: правильный ответ отмечается слева.");
                if (std::regex_search(s,std::regex(R"(\^[−\-0-9.,]+$)"))) bad("Не заканчивайте вариант записью ^число: это служебная разметка баллов.");
                if (!trim(c.weight).empty() && !integer(c.weight)) bad("Балл за пункт должен быть целым неотрицательным числом.");
                if (c.correct) correct++;
            }
            if ((t=="single" || t=="dropdown") && correct!=1) bad("Отметьте ровно один правильный ответ.");
            if (t=="multi" && correct==0) bad("Отметьте хотя бы один правильный ответ.");
        } else if (t=="matching") {
            if (q.pairs.size()<2 || q.pairs.size()>200) bad("Нужно от 2 до 200 пар соответствий.");
            for (const auto& a:q.pairs) {plain(a.left,"Левая часть пары");plain(a.right,"Правая часть пары");if(a.left.find("=>")!=std::string::npos || a.right.find("=>")!=std::string::npos) bad("Не используйте => внутри частей пары: это служебный разделитель.");}
        } else if (t=="ordering") {
            if (q.items.size()<2 || q.items.size()>1000) bad("Укажите от 2 до 1000 элементов последовательности.");
            for (const auto& s:q.items) plain(s,"Последовательность");
        } else if (t=="text" || t=="word_scramble") {
            if (q.answers.empty() || q.answers.size()>1000) bad("Укажите от 1 до 1000 допустимых ответов.");
            for (const auto& s:q.answers) plain(s,"Допустимые ответы");
        } else if (t=="number" || t=="slider") {
            double v=0,tol=0;
            if (!number(get(q.f,"target_value"),&v)) bad("Укажите правильное число. Можно использовать точку или запятую.");
            if (!number(get(q.f,"tolerance"),&tol) || tol<0) bad("Погрешность должна быть числом не меньше нуля.");
            if (t=="slider") {
                double mn=0,mx=0,st=0;
                bool a=number(q.param("min","0"),&mn), b=number(q.param("max","100"),&mx), c=number(q.param("step","1"),&st);
                if (!a||!b||mn>=mx) bad("У шкалы минимум должен быть меньше максимума.");
                if (!c||st<=0) bad("Шаг шкалы должен быть больше нуля.");
                if (a&&b&&number(get(q.f,"target_value"))&&(v<mn||v>mx)) bad("Правильное число находится вне границ шкалы.");
            }
        } else if (t=="fill_blank" || t=="dictation") {
            auto s=get(q.f,"template"); size_t at=0, count=0; bool malformed=false;
            while (at<s.size()) {
                size_t a=s.find_first_of("{}",at); if(a==std::string::npos) break;
                if(s[a]=='}') {malformed=true;break;}
                size_t b=s.find('}',a+1), nested=s.find('{',a+1);
                if(b==std::string::npos || (nested!=std::string::npos&&nested<b)) {malformed=true;break;}
                auto inner=trim(s.substr(a+1,b-a-1)); if(!inner.empty()&&inner[0]=='=') inner=trim(inner.substr(1));
                if (inner.empty() || trim(inner.substr(0,inner.find('|'))).empty()) malformed=true;
                count++; at=b+1;
            }
            if (count==0 || malformed) bad("Проверьте пропуски: нужен текст вида «Столица — {Москва}», без пустых или незакрытых скобок.");
        }
        auto ex=parseExtra(get(q.f,"extra"));
        auto extraText=get(q.f,"extra");std::replace(extraText.begin(),extraText.end(),'\n',';');
        for(const auto& part:split(extraText,';')) if(part.find('=')==std::string::npos) bad("Доп. параметры: ожидается запись ключ=значение через точку с запятой.");
        const std::vector<std::string> supportedExtra={"min","max","step","extra_letters","audio_url","scoring","mistakes","mode","distractors","min_words","max_words","keywords","min_keywords","match","typo","shuffle","case_sensitive","show_points","hide_points"};
        for(const auto& a:ex) if(std::find(supportedExtra.begin(),supportedExtra.end(),a.first)==supportedExtra.end()) bad("Неизвестный дополнительный параметр: "+a.first);
        auto allowed=[&](const std::string& key,const std::vector<std::string>& values){if(ex.count(key)&&std::find(values.begin(),values.end(),ex[key])==values.end())bad("Недопустимое значение параметра "+key);};
        allowed("match",{"exact","contains_any","contains_all","fuzzy","regex"});allowed("mode",{"input","dropdown","word_bank"});allowed("scoring",{"proportional","all_or_nothing"});
        for(const auto& key:{"shuffle","case_sensitive"})allowed(key,{"0","1"});
        if(!get(q.f,"shared_text_id").empty()&&!std::regex_match(get(q.f,"shared_text_id"),std::regex("[a-z0-9_-]+")))bad("ID общего текста: только строчные латинские буквы, цифры, дефис и подчёркивание.");
        for(const auto& k:{"min_words","max_words","min_keywords","mistakes","typo"}) if(ex.count(k)&&!integer(ex[k])) bad(std::string("Параметр ")+k+" должен быть целым неотрицательным числом.");
        if(t=="essay"&&ex.count("min_words")&&ex.count("max_words")&&integer(ex["min_words"])&&integer(ex["max_words"])&&std::stoll(ex["max_words"])>0&&std::stoll(ex["min_words"])>std::stoll(ex["max_words"])) bad("Минимальный объём эссе больше максимального.");
        auto url=trim(get(q.f,"image_url"));
        if(!url.empty() && url.rfind("https://",0)!=0 && url.rfind("http://",0)!=0) bad("Для изображения нужна полная ссылка http:// или https://, а не путь на ПК.");
        auto audio=get(ex,"audio_url");
        if(!audio.empty() && audio.rfind("https://",0)!=0 && audio.rfind("http://",0)!=0) bad("Для аудио нужна полная ссылка http:// или https://.");
        auto row=toRow(q);
        for(const auto& a:row) if(textLength(a.second)>32767) bad("Поле «"+a.first+"» превышает лимит Excel: 32 767 символов.");
    }
    return out;
}
inline double decimal(const std::string& s,double fallback=0) { double n; return number(s,&n)?n:fallback; }
inline int intParam(const Row& p,const std::string& k,int fallback=0) { return integer(get(p,k))?std::stoi(get(p,k)):fallback; }
inline std::vector<std::string> tokens(std::string s) { for(auto& c:s) if(c==','||c==';')c='|'; return split(s,'|'); }
inline json structuredQuestion(const Question& q) {
    auto r=toRow(q),ex=parseExtra(r["extra"]);auto t=q.type();
    json o={{"explanation",trim(r["explanation"])},{"group_name",trim(r["group_name"])},{"is_required",q.required?1:0},{"shared_text_id",trim(r["shared_text_id"])},{"show_points",q.hidePoints?0:1}};
    if(!trim(r["image_url"]).empty())o["image_url"]=trim(r["image_url"]);
    if(ex.count("shuffle"))o["shuffle_answers"]=truth(ex["shuffle"])?1:0;
    int sensitive=truth(get(ex,"case_sensitive"))?1:0;
    if(isChoice(t)) {
        o["choices"]=json::array();
        for(size_t i=0;i<q.choices.size();i++){const auto& c=q.choices[i];json weight=trim(c.weight).empty()?json(nullptr):json(std::stoll(trim(c.weight)));o["choices"].push_back({{"id","c"+std::to_string(i+1)},{"text",trim(c.text)},{"is_correct",c.correct?1:0},{"points",weight}});}
    }else if(t=="boolean")o["choices"]=json::array({{{"id","true"},{"text","Верно / Да"},{"is_correct",q.booleanAnswer?1:0}},{{"id","false"},{"text","Неверно / Нет"},{"is_correct",q.booleanAnswer?0:1}}});
    else if(t=="number"||t=="slider") {
        o["target_value"]=decimal(r["target_value"]);o["tolerance"]=decimal(r["tolerance"]);
        if(t=="slider"){o["min"]=decimal(get(ex,"min","0"));o["max"]=decimal(get(ex,"max","100"));o["step"]=decimal(get(ex,"step","1"));}
    }else if(t=="text") {o["answers"]=split(r["answers"],'|');o["match_mode"]=get(ex,"match","fuzzy");o["case_sensitive"]=sensitive;o["typo_tolerance"]=std::clamp(intParam(ex,"typo",1),0,10);}
    else if(t=="matching") {o["pairs"]=json::array();for(size_t i=0;i<q.pairs.size();i++)o["pairs"].push_back({{"id","p"+std::to_string(i+1)},{"left",trim(q.pairs[i].left)},{"right",trim(q.pairs[i].right)},{"points",nullptr}});}
    else if(t=="ordering") {o["items"]=json::array();for(size_t i=0;i<q.items.size();i++)o["items"].push_back({{"id","ord_"+std::to_string(i+1)},{"text",trim(q.items[i])},{"points",nullptr}});}
    else if(t=="fill_blank") {o["template"]=trim(r["template"]);o["case_sensitive"]=sensitive;o["choice_mode"]=get(ex,"mode","input");o["distractors"]=get(ex,"distractors");}
    else if(t=="dictation") {o["template"]=trim(r["template"]);o["audio_url"]=get(ex,"audio_url");o["scoring_mode"]=get(ex,"scoring")=="all_or_nothing"?"all_or_nothing":"proportional";o["allowed_mistakes"]=intParam(ex,"mistakes");}
    else if(t=="word_scramble") {auto words=tokens(r["answers"]);o["words"]=words;o["target_word"]=words.empty()?"":words.front();auto letters=get(ex,"extra_letters");letters.erase(std::remove_if(letters.begin(),letters.end(),[](unsigned char c){return c<128&&!((c>='0'&&c<='9')||(c>='A'&&c<='Z')||(c>='a'&&c<='z'));}),letters.end());o["extra_letters"]=letters;o["case_sensitive"]=sensitive;}
    else if(t=="essay") {o["min_words"]=intParam(ex,"min_words");o["max_words"]=intParam(ex,"max_words");auto keys=tokens(get(ex,"keywords"));o["keywords"]=keys;o["min_keywords"]=intParam(ex,"min_keywords");o["auto_check"]=keys.empty()?0:1;o["scoring_mode"]=get(ex,"scoring")=="all_or_nothing"?"all_or_nothing":"proportional";o["case_sensitive"]=sensitive;}
    return {{"question_type",t},{"title",trim(r["title"])},{"content",r["content"]},{"points",std::stoi(trim(r["points"]))},{"penalty",std::stoi(trim(r["penalty"]))},{"options",o}};
}
inline std::string exportJson(const Project& p) {
    json qs=json::array();for(const auto& q:p.questions)qs.push_back(structuredQuestion(q));
    return json({{"format","wp-olympiad-questions"},{"template_version","2.0"},{"olympiad_title",p.name},{"encoding","UTF-8"},{"questions",qs}}).dump(2,' ',false,json::error_handler_t::strict)+"\n";
}
inline std::string csvCell(const std::string& s) {
    std::string o="\"";for(char c:s) {if(c=='"')o+='"';o+=c;} return o+'"';
}
inline std::string exportCsv(const Project& p) {
    std::string out="\xef\xbb\xbf";
    auto row=[&](const Row& r,bool header){for(size_t i=0;i<columns.size();++i){if(i)out+=';';out+=csvCell(header?columns[i]:get(r,columns[i]));}out+="\r\n";};
    row({},true);for(const auto& q:p.questions)row(toRow(q),false);return out;
}
inline std::string xml(const std::string& s) {
    std::string o;
    for(unsigned char c:s) {switch(c) {case '&':o+="&amp;";break;case '<':o+="&lt;";break;case '>':o+="&gt;";break;case '"':o+="&quot;";break;case '\'':o+="&apos;";break;case '\r':o+="&#13;";break;default:if(c>=32||c=='\n'||c=='\t')o+=c;}}return o;
}
inline uint32_t crc32(const std::string& s) {
    uint32_t c=0xffffffff;for(unsigned char b:s){c^=b;for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0xedb88320:0);}return c^0xffffffff;
}
inline void u16(std::string& s,uint16_t n){s+=char(n);s+=char(n>>8);}
inline void u32(std::string& s,uint32_t n){u16(s,n&0xffff);u16(s,n>>16);}
inline std::string zipStore(const std::vector<std::pair<std::string,std::string>>& files) {
    std::string out,central;
    for(const auto& file:files){const auto& name=file.first;const auto& data=file.second;auto off=out.size();auto crc=crc32(data);
        u32(out,0x04034b50);u16(out,20);u16(out,0x800);u16(out,0);u16(out,0);u16(out,0x5d52);u32(out,crc);u32(out,data.size());u32(out,data.size());u16(out,name.size());u16(out,0);out+=name;out+=data;
        u32(central,0x02014b50);u16(central,20);u16(central,20);u16(central,0x800);u16(central,0);u16(central,0);u16(central,0x5d52);u32(central,crc);u32(central,data.size());u32(central,data.size());u16(central,name.size());u16(central,0);u16(central,0);u16(central,0);u16(central,0);u32(central,0);u32(central,off);central+=name;
    }
    auto off=out.size();out+=central;u32(out,0x06054b50);u16(out,0);u16(out,0);u16(out,files.size());u16(out,files.size());u32(out,central.size());u32(out,off);u16(out,0);return out;
}
inline std::string cellRef(int col,int row){std::string c;do{c=char('A'+col%26)+c;col=col/26-1;}while(col>=0);return c+std::to_string(row);}
inline std::string xlsxCell(int col,int row,const std::string& value,int style=0){return "<c r=\""+cellRef(col,row)+"\" t=\"inlineStr\" s=\""+std::to_string(style)+"\"><is><t xml:space=\"preserve\">"+xml(value)+"</t></is></c>";}
inline std::string exportXlsx(const Project& p) {
    const std::string decl="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
    const std::string ns="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    std::string sheet=decl+"<worksheet xmlns=\""+ns+"\"><dimension ref=\"A1:Q"+std::to_string(p.questions.size()+1)+"\"/><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"42\"/><cols>";
    int widths[]={20,62,9,9,24,58,20,18,16,38,50,16,42,38,18,58,55};
    for(int i=0;i<17;i++)sheet+="<col min=\""+std::to_string(i+1)+"\" max=\""+std::to_string(i+1)+"\" width=\""+std::to_string(widths[i])+"\" customWidth=\"1\"/>";
    sheet+="</cols><sheetData><row r=\"1\" ht=\"30\" customHeight=\"1\">";
    for(int i=0;i<17;i++)sheet+=xlsxCell(i,1,columns[i],1);
    sheet+="</row>";
    for(size_t i=0;i<p.questions.size();i++){auto r=toRow(p.questions[i]);int n=i+2;sheet+="<row r=\""+std::to_string(n)+"\">";for(int j=0;j<17;j++)sheet+=xlsxCell(j,n,get(r,columns[j]),i%2?3:2);sheet+="</row>";}
    sheet+="</sheetData><autoFilter ref=\"A1:Q"+std::to_string(p.questions.size()+1)+"\"/><pageMargins left=\"0.25\" right=\"0.25\" top=\"0.5\" bottom=\"0.5\" header=\"0.2\" footer=\"0.2\"/></worksheet>";
    std::string help=decl+"<worksheet xmlns=\""+ns+"\"><cols><col min=\"1\" max=\"1\" width=\"24\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"95\" customWidth=\"1\"/></cols><sheetData>";
    std::vector<std::pair<std::string,std::string>> h={{"WP Olympiad","Файл вопросов для импорта • "+p.name},{"Как импортировать","Откройте олимпиаду → Конструктор вопросов → Импорт вопросов. Выберите этот XLSX. Либо положите файл в подключённую сетевую папку."},{"Важно","Не меняйте заголовки на листе «Вопросы». Проект для дальнейшего редактирования сохраняется отдельно в формате .wpoq."},{"Баллы","Баллы скрываются по умолчанию. Значение show_points в extra задаётся галочкой редактора для каждого вопроса."},{"Изображения","Только ссылки http(s) на изображения, доступные сайту. Локальные картинки не встраиваются."}};
    for(size_t i=0;i<columns.size();i++)h.push_back({columns[i],columnLabels[i]});
    for(size_t i=0;i<typeCodes.size();i++)h.push_back({typeCodes[i],typeLabels[i]});
    for(size_t i=0;i<h.size();i++)help+="<row r=\""+std::to_string(i+1)+"\" ht=\"40\" customHeight=\"1\">"+xlsxCell(0,i+1,h[i].first,i?2:1)+xlsxCell(1,i+1,h[i].second,i?2:1)+"</row>";
    help+="</sheetData></worksheet>";
    std::string styles=decl+R"(<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><color rgb="FF162F35"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF116D68"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF0F7F6"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>)";
    return zipStore({
        {"[Content_Types].xml",decl+R"(<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>)"},
        {"_rels/.rels",decl+R"(<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>)"},
        {"xl/workbook.xml",decl+R"(<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets><sheet name="Вопросы" sheetId="1" r:id="rId1"/><sheet name="Справка" sheetId="2" r:id="rId2"/></sheets></workbook>)"},
        {"xl/_rels/workbook.xml.rels",decl+R"(<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>)"},
        {"xl/styles.xml",styles},{"xl/worksheets/sheet1.xml",sheet},{"xl/worksheets/sheet2.xml",help}
    });
}
}
