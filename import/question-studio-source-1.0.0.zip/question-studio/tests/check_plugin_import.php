<?php
use WPOlympiad\NetworkImport;
use WPOlympiad\Quiz;
use WPOlympiad\Question;

$base = '/home/user/question-studio/tests';
$expected_types = ['single','multi','dropdown','boolean','number','text','matching','ordering','fill_blank','slider','word_scramble','dictation','essay'];
$canonical = null;
global $checks;
$checks = 0;
function studio_sorted($a) { if (!is_array($a)) return $a; foreach ($a as &$v) $v=studio_sorted($v); unset($v); if (!array_is_list($a)) ksort($a); return $a; }
function studio_assert($ok, $message) {
    global $checks;
    if (!$ok) throw new RuntimeException($message);
    $checks++;
}
foreach (['exports','windows-exports'] as $dir) {
    foreach (['xlsx','csv','json'] as $ext) {
        $path = "$base/$dir/questions.$ext";
        $analysis = NetworkImport::analyze_questions_content(file_get_contents($path), basename($path));
        studio_assert($analysis['stats']['importable'] === 13, "$dir/$ext: 13 importable questions");
        studio_assert($analysis['stats']['errors'] === 0, "$dir/$ext: no errors");
        studio_assert($analysis['stats']['warnings'] === 0, "$dir/$ext: no warnings");
        $qs = $analysis['questions'];
        studio_assert(array_column($qs,'question_type') === $expected_types, "$dir/$ext: correct types");
        foreach ($qs as $q) studio_assert($q['options']['show_points'] === 0, "$dir/$ext: hide points");
        if ($canonical === null) $canonical = $qs;
        else studio_assert(studio_sorted($qs) === studio_sorted($canonical), "$dir/$ext: all parsed questions exactly match");
        studio_assert($qs[0]['options']['choices'][2]['text'] === 'Марс' && $qs[0]['options']['choices'][2]['is_correct'] === 1, "$dir/$ext: single answer");
        studio_assert($qs[1]['options']['choices'][0]['points'] === 2 && $qs[1]['options']['choices'][2]['is_correct'] === 1, "$dir/$ext: multi scores");
        studio_assert(abs($qs[4]['options']['target_value'] - 9.8) < 0.00001, "$dir/$ext: decimal comma");
        studio_assert(count($qs[6]['options']['pairs']) === 4, "$dir/$ext: matching pairs");
        studio_assert(count($qs[7]['options']['items']) === 4, "$dir/$ext: ordering");
        studio_assert($qs[9]['options']['min'] == 0 && $qs[9]['options']['max'] == 10 && $qs[9]['options']['step'] == 1, "$dir/$ext: slider bounds");
        echo "$dir/$ext: 13/13, warnings=0, errors=0; answers, scores and options match\n";
    }
}
foreach (['xlsx','csv','json'] as $ext) {
    $path = "$base/exports/special.$ext";
    $a = NetworkImport::analyze_questions_content(file_get_contents($path), basename($path));
    studio_assert($a['stats']['importable'] === 13, "special/$ext: all importable");
    studio_assert($a['stats']['errors'] === 0, "special/$ext: no errors");
    studio_assert($a['questions'][0]['options']['show_points'] === 1, "special/$ext: explicit visible points");
    studio_assert(str_contains($a['questions'][0]['title'], 'ё ∑ π ≥ 你好'), "special/$ext: Unicode preserved");
    echo "special/$ext: Cyrillic, newlines, Unicode and visible-points override OK\n";
}
foreach (['xlsx','csv','json'] as $ext) {
    $path = "$base/gui-exports/GUI вопросы.$ext";
    $a = NetworkImport::analyze_questions_content(file_get_contents($path),basename($path));
    studio_assert($a['stats']['importable'] === 13, "GUI/$ext: all importable");
    studio_assert($a['stats']['errors'] === 0 && $a['stats']['warnings'] === 0, "GUI/$ext: no warnings or errors");
    studio_assert($a['questions'][0]['options']['show_points'] === 1, "GUI/$ext: unchecked hide-points retained");
    studio_assert($a['questions'][0]['options']['choices'][1]['is_correct'] === 1 && $a['questions'][0]['options']['choices'][2]['is_correct'] === 0, "GUI/$ext: edited correct answer retained");
    studio_assert(str_contains($a['questions'][0]['title'], 'Кириллица, ё'), "GUI/$ext: edited multiline title retained");
    echo "GUI/$ext: Unicode filename, edited title, correct radio selection and visible points OK\n";
}
$id = Quiz::create(['title'=>'Desktop editor import compatibility','settings'=>Quiz::default_settings()]);
studio_assert($id > 0, 'Temporary quiz saved');
try {
    $r = NetworkImport::import_to_quiz($id,$canonical,'replace',true);
    $stored = Question::get_by_quiz($id);
    studio_assert(count($stored)===13,'13 questions actually written to database');
    foreach ($stored as $i=>$q) {
        studio_assert($q->question_type === $expected_types[$i], 'Stored question type');
        studio_assert((int)$q->options['show_points']===0,'Stored hidden points');
        studio_assert($q->points === (int)$canonical[$i]['points'],'Stored integer score');
    }
    echo "Database import: 13 questions, all types/scores/hidden-points retained\n";
} finally {
    Quiz::delete($id);
}
echo "PASS: $checks import compatibility assertions\n";
