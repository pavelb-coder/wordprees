// SPDX-License-Identifier: GPL-2.0-or-later
#include <windows.h>
#include <string>
#include <iostream>
std::wstring text(HWND h){int n=(int)SendMessageW(h,WM_GETTEXTLENGTH,0,0);std::wstring s(n+1,0);SendMessageW(h,WM_GETTEXT,n+1,(LPARAM)s.data());s.resize(n);return s;}
HWND wait(const wchar_t* cls,const wchar_t* title){for(int i=0;i<100;i++){HWND h=FindWindowW(cls,title);if(h)return h;Sleep(30);}return nullptr;}
int wmain(int argc,wchar_t** argv){if(argc<2)return 1;HWND h=wait(L"WPOQuestionStudio",nullptr);if(!h)return 2;std::wstring mode=argv[1];
 if(mode==L"prepare"){SetWindowTextW(GetDlgItem(h,101),L"Проверка восстановления черновика");SendMessageW(h,WM_TIMER,2,0);wchar_t path[32768];GetEnvironmentVariableW(L"LOCALAPPDATA",path,32768);std::wstring p=std::wstring(path)+L"\\WP Olympiad Question Studio\\recovery.wpoq";bool ok=GetFileAttributesW(p.c_str())!=INVALID_FILE_ATTRIBUTES;std::cout<<(ok?"PASS":"FAIL")<<": recovery persisted before simulated crash\n";return ok?0:1;}
 if(mode==L"restore"||mode==L"verify"){if(mode==L"restore"){auto d=wait(L"#32770",L"Автовосстановление");if(!d){std::cout<<"FAIL: recovery prompt\n";return 1;}PostMessageW(d,WM_COMMAND,IDYES,0);}bool ok=false;for(int i=0;i<100;i++){if(text(GetDlgItem(h,101))==L"Проверка восстановления черновика" && SendMessageW(GetDlgItem(h,100),LB_GETCOUNT,0,0)==13){ok=true;break;}Sleep(30);}ok=ok&&SendMessageW(GetDlgItem(h,100),LB_GETCOUNT,0,0)==13;std::cout<<(ok?"PASS":"FAIL")<<": recovery prompt restores project name and 13 questions after process termination\n";if(ok)SendMessageW(h,WM_COMMAND,104,0);return ok?0:1;}
 if(mode==L"samples"){SendMessageW(h,WM_COMMAND,115,0);return 0;}
 if(mode==L"close"){PostMessageW(h,WM_CLOSE,0,0);auto d=wait(L"#32770",L"Сохранение проекта");if(d)PostMessageW(d,WM_COMMAND,IDNO,0);return 0;}
 return 1;}
