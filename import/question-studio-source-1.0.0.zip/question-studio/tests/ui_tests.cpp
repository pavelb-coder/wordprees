#define NOMINMAX
#include <windows.h>
#include <commctrl.h>
#include <fstream>
#include <string>
#include <vector>
#include <iostream>
int pass=0,fail=0;
void check(bool b,const char* s){std::cout<<(b?"OK ":"FAIL ")<<s<<"\n";if(b)pass++;else fail++;}
std::wstring txt(HWND h){int n=GetWindowTextLengthW(h);std::wstring s(n+1,0);GetWindowTextW(h,s.data(),n+1);s.resize(n);return s;}
HWND named(HWND parent,const wchar_t* name){for(HWND c=GetWindow(parent,GW_CHILD);c;c=GetWindow(c,GW_HWNDNEXT))if(txt(c)==name)return c;return nullptr;}
HWND waitDialog(const wchar_t* title){for(int i=0;i<150;i++){HWND h=FindWindowW(L"#32770",title);if(h)return h;Sleep(40);}return nullptr;}
void chooseFilename(HWND d,const std::wstring& path){HWND e=GetDlgItem(d,1148);if(!e)e=GetDlgItem(d,1152);if(!e){auto callback=[](HWND h,LPARAM l)->BOOL{wchar_t cls[30];GetClassNameW(h,cls,30);if(_wcsicmp(cls,L"EDIT")==0)*(HWND*)l=h;return TRUE;};EnumChildWindows(d,callback,(LPARAM)&e);}if(e){SendMessageW(e,WM_SETTEXT,0,(LPARAM)path.c_str());PostMessageW(d,WM_COMMAND,IDOK,0);}else check(false,"file-dialog edit found");}
bool waitFile(const std::wstring& p){for(int i=0;i<150;i++){if(GetFileAttributesW(p.c_str())!=INVALID_FILE_ATTRIBUTES)return true;Sleep(40);}return false;}
void dump(HWND p,int depth=0){for(HWND c=GetWindow(p,GW_CHILD);c;c=GetWindow(c,GW_HWNDNEXT)){wchar_t cls[90];GetClassNameW(c,cls,90);std::wstring s=txt(c);std::wcout<<std::wstring(depth*2,L' ')<<GetDlgCtrlID(c)<<L" "<<cls<<L" "<<s.substr(0,100)<<L"\n";}}
int wmain(int argc,wchar_t** argv){
    std::cout.setf(std::ios::unitbuf);
    HWND main=FindWindowW(L"WPOQuestionStudio",nullptr);if(!main){check(false,"app window exists");return 1;}
    if(argc>1&&std::wstring(argv[1])==L"--dump"){dump(main);auto f=FindWindowExW(main,nullptr,L"WPOQuestionForm",nullptr);dump(f,1);return 0;}
    HWND list=GetDlgItem(main,100);HWND form=FindWindowExW(main,nullptr,L"WPOQuestionForm",nullptr);
    check(list&&form,"native list and editor exist");check(SendMessageW(list,LB_GETCOUNT,0,0)==13,"13 sample questions listed");
    for(int i=0;i<13;i++){
        SendMessageW(list,LB_SETCURSEL,i,0);SendMessageW(main,WM_COMMAND,MAKEWPARAM(100,LBN_SELCHANGE),(LPARAM)list);
        HWND combo=GetDlgItem(form,123);check(SendMessageW(combo,CB_GETCURSEL,0,0)==i,"correct type shown for selected question");
        HWND hide=named(form,L"Скрыть баллы по этому вопросу в тесте");check(hide&&SendMessageW(hide,BM_GETCHECK,0,0)==BST_CHECKED,"hidden-points checkbox checked");
        SendMessageW(main,WM_COMMAND,121,0);check(named(form,L"Изображение к заданию — ссылка")!=nullptr,"advanced tab built");
        SendMessageW(main,WM_COMMAND,122,0);check(named(form,L"ПРЕДПРОСМОТР ДЛЯ УЧАСТНИКА")!=nullptr,"preview tab built");
        SendMessageW(main,WM_COMMAND,120,0);
    }
    SendMessageW(list,LB_SETCURSEL,0,0);SendMessageW(main,WM_COMMAND,MAKEWPARAM(100,LBN_SELCHANGE),(LPARAM)list);
    HWND combo=GetDlgItem(form,123);SendMessageW(combo,CB_SHOWDROPDOWN,TRUE,0);RECT drop{};SendMessageW(combo,CB_GETDROPPEDCONTROLRECT,0,(LPARAM)&drop);check(drop.bottom-drop.top>100,"type dropdown has usable height");SendMessageW(combo,CB_SHOWDROPDOWN,FALSE,0);
    std::vector<HWND> radios;HWND titleEdit=nullptr;
    for(HWND c=GetWindow(form,GW_CHILD);c;c=GetWindow(c,GW_HWNDNEXT)){
        wchar_t cl[30];GetClassNameW(c,cl,30);auto s=txt(c);
        if(s==L"Текст вопроса *") { titleEdit=GetDlgItem(form,GetDlgCtrlID(c)+1); }
        if(_wcsicmp(cl,L"BUTTON")==0&&((GetWindowLongPtrW(c,GWL_STYLE)&0xf)==BS_AUTORADIOBUTTON))radios.push_back(c);
    }
    check(titleEdit!=nullptr&&radios.size()==4,"title editor and four radio choices found");
    if(radios.size()==4){SendMessageW(radios[1],BM_CLICK,0,0);int n=0;for(auto r:radios)n+=SendMessageW(r,BM_GETCHECK,0,0)==BST_CHECKED;check(n==1&&SendMessageW(radios[1],BM_GETCHECK,0,0)==BST_CHECKED,"single-answer radio exclusivity");}
    if(titleEdit)SetWindowTextW(titleEdit,L"Проверка программы: 2 + 2 = ?\r\nКириллица, ё и «кавычки»");
    auto hide=named(form,L"Скрыть баллы по этому вопросу в тесте");SendMessageW(hide,BM_CLICK,0,0);check(SendMessageW(hide,BM_GETCHECK,0,0)==BST_UNCHECKED,"hidden-points option can be disabled");
    std::wstring root=L"Z:\\home\\user\\question-studio\\tests\\gui-exports";CreateDirectoryW(root.c_str(),nullptr);
    DeleteFileW((root+L"\\GUI проект.wpoq").c_str());PostMessageW(main,WM_COMMAND,104,0);auto d=waitDialog(L"Сохранение файла");check(d!=nullptr,"project Save dialog opens");if(d)chooseFilename(d,root+L"\\GUI проект.wpoq");if(!waitFile(root+L"\\GUI проект.wpoq")){check(false,"Unicode project filename saved");return 1;}check(true,"Unicode project filename saved");
    struct Format{int id;const wchar_t* ext;};for(auto f:std::vector<Format>{{116,L"xlsx"},{117,L"csv"},{118,L"json"}}){auto p=root+L"\\GUI вопросы."+f.ext;DeleteFileW(p.c_str());PostMessageW(main,WM_COMMAND,f.id,0);d=waitDialog(L"Сохранение файла");check(d!=nullptr,"export Save dialog opens");if(d)chooseFilename(d,p);check(waitFile(p),"Unicode export filename saved");d=waitDialog(L"Экспорт завершён");check(d!=nullptr,"export success message");if(d)PostMessageW(d,WM_COMMAND,IDOK,0);Sleep(80);}
    SendMessageW(main,WM_COMMAND,109,0);check(SendMessageW(list,LB_GETCOUNT,0,0)==14,"duplicate question");SendMessageW(main,WM_COMMAND,111,0);check(SendMessageW(list,LB_GETCURSEL,0,0)==0,"move duplicate up");SendMessageW(main,WM_COMMAND,112,0);check(SendMessageW(list,LB_GETCURSEL,0,0)==1,"move duplicate down");
    PostMessageW(main,WM_COMMAND,110,0);d=waitDialog(L"Удаление вопроса");check(d!=nullptr,"delete confirmation");if(d)PostMessageW(d,WM_COMMAND,IDYES,0);for(int i=0;i<50&&SendMessageW(list,LB_GETCOUNT,0,0)!=13;i++)Sleep(40);check(SendMessageW(list,LB_GETCOUNT,0,0)==13,"delete selected question");
    SendMessageW(main,WM_TIMER,2,0);check(true,"recovery timer completed without error");
    wchar_t appdata[32768]{};GetEnvironmentVariableW(L"LOCALAPPDATA",appdata,32768);auto recovery=std::wstring(appdata)+L"\\WP Olympiad Question Studio\\recovery.wpoq";check(GetFileAttributesW(recovery.c_str())!=INVALID_FILE_ATTRIBUTES,"recovery file created in LocalAppData");
    SendMessageW(main,WM_COMMAND,104,0);Sleep(120);check(GetFileAttributesW(recovery.c_str())==INVALID_FILE_ATTRIBUTES,"successful save clears recovery file");
    SetWindowPos(main,nullptr,20,20,1040,700,SWP_NOZORDER);check(IsWindow(main),"resizing to minimum supported size");SetWindowPos(main,nullptr,84,60,1280,900,SWP_NOZORDER);
    SendMessageW(list,LB_SETCURSEL,0,0);SendMessageW(main,WM_COMMAND,MAKEWPARAM(100,LBN_SELCHANGE),(LPARAM)list);
    std::cout<<"RESULT "<<pass<<" passed, "<<fail<<" failed\n";return fail?1:0;
}
