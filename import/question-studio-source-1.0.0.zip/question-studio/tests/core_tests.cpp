#include "../src/core.hpp"
#include "../src/samples.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace studio;
int passed=0,failed=0;
void check(bool ok,const std::string& name){if(ok){passed++;std::cout<<"OK "<<passed<<" "<<name<<"\n";}else{failed++;std::cerr<<"FAIL "<<name<<"\n";}}
void write(const std::filesystem::path& path,const std::string& data){std::ofstream f(path,std::ios::binary);f<<data;if(!f)throw std::runtime_error("Write failed");}
int main(int argc,char** argv){
    const auto p=sampleProject();
    check(p.questions.size()==13,"13 supported types");
    check(validate(p).empty(),"all examples pass validation");
    check(typeCodes.size()==typeLabels.size(),"type labels in sync");
    check(columns.size()==17&&columnLabels.size()==17,"17 canonical columns");
    check(projectText(readProject(projectText(p)))==projectText(p),"project round-trip is lossless");
    check(readProject("\xef\xbb\xbf"+projectText(p)).questions.size()==13,"project UTF-8 BOM");
    for(size_t i=0;i<13;i++){
        check(p.questions[i].type()==typeCodes[i],"type order: "+typeCodes[i]);
        check(p.questions[i].hidePoints,"hide points default: "+typeCodes[i]);
        check(parseExtra(toRow(p.questions[i])["extra"])["show_points"]=="0","hidden points export: "+typeCodes[i]);
        auto round=fromRow(toRow(p.questions[i]));
        check(toRow(round)==toRow(p.questions[i]),"canonical row round-trip: "+typeCodes[i]);
    }
    auto one=[&](size_t i){Project a;a.questions={p.questions[i]};return a;};
    auto a=one(0);a.questions[0].hidePoints=false;check(parseExtra(toRow(a.questions[0])["extra"])["show_points"]=="1","show points override");
    a.questions[0].f["extra"]="show_points=0; hide_points=1; shuffle=1";check(parseExtra(toRow(a.questions[0])["extra"])["show_points"]=="1","checkbox overrides raw extras");
    check(!parseExtra(toRow(a.questions[0])["extra"]).count("hide_points"),"no conflicting hide_points export");
    a=one(0);a.questions[0].f["title"]="";check(!validate(a).empty(),"empty title blocked");
    a=one(0);a.questions[0].f["points"]="1.5";check(!validate(a).empty(),"fractional points blocked");
    a=one(0);a.questions[0].f["penalty"]="-1";check(!validate(a).empty(),"negative penalty blocked");
    a=one(0);a.questions[0].f["points"]="1000001";check(!validate(a).empty(),"score bound");
    a=one(0);a.questions[0].choices.resize(1);check(!validate(a).empty(),"one choice blocked");
    a=one(0);for(auto& c:a.questions[0].choices)c.correct=false;check(!validate(a).empty(),"missing correct answer blocked");
    a=one(0);a.questions[0].choices[0].correct=true;check(!validate(a).empty(),"multiple correct for single blocked");
    a=one(0);a.questions[0].choices[0].text="A | B";check(!validate(a).empty(),"reserved pipe in choice blocked");
    a=one(0);a.questions[0].choices[0].text="*star";check(!validate(a).empty(),"reserved star blocked");
    a=one(0);a.questions[0].choices[0].text="test^2";check(!validate(a).empty(),"reserved point suffix blocked");
    a=one(0);a.questions[0].choices[0].weight="-1";check(!validate(a).empty(),"negative item weight blocked");
    a=one(1);check(validate(a).empty(),"multiple correct for multi accepted");
    a=one(4);a.questions[0].f["target_value"]="9,8";check(validate(a).empty(),"comma decimal accepted");
    a=one(4);a.questions[0].f["target_value"]="x";check(!validate(a).empty(),"nonnumeric target blocked");
    a=one(4);a.questions[0].f["tolerance"]="-0.1";check(!validate(a).empty(),"negative tolerance blocked");
    a=one(9);a.questions[0].setParam("min","10");a.questions[0].setParam("max","0");check(!validate(a).empty(),"reversed slider bounds blocked");
    a=one(9);a.questions[0].setParam("step","0");check(!validate(a).empty(),"zero slider step blocked");
    a=one(9);a.questions[0].f["target_value"]="999";check(!validate(a).empty(),"target outside slider range blocked");
    a=one(5);a.questions[0].answers.clear();check(!validate(a).empty(),"empty text answer blocked");
    a=one(10);a.questions[0].answers.clear();check(!validate(a).empty(),"empty anagram blocked");
    a=one(6);a.questions[0].pairs.resize(1);check(!validate(a).empty(),"one pair blocked");
    a=one(6);a.questions[0].pairs[0].right="";check(!validate(a).empty(),"empty pair side blocked");
    a=one(7);a.questions[0].items.resize(1);check(!validate(a).empty(),"short sequence blocked");
    for(auto s:{"no blanks","{}","{=}","{x","}x","{{a}}","{a} }"}){a=one(8);a.questions[0].f["template"]=s;check(!validate(a).empty(),std::string("invalid template: ")+s);}
    a=one(8);a.questions[0].f["template"]="Столица {Москва|москва}.";check(validate(a).empty(),"valid Unicode blank");
    a=one(12);a.questions[0].setParam("min_words","300");a.questions[0].setParam("max_words","100");check(!validate(a).empty(),"reversed essay bounds blocked");
    a=one(0);a.questions[0].f["extra"]="shuffle:1";check(!validate(a).empty(),"malformed extras blocked");
    a=one(0);a.questions[0].f["image_url"]="C:\\Pictures\\q.png";check(!validate(a).empty(),"local picture URL blocked");
    a=one(0);a.questions[0].f["image_url"]="https://school.ru/картинка.png";check(validate(a).empty(),"HTTPS picture accepted");
    a=one(11);a.questions[0].setParam("audio_url","file:///q.mp3");check(!validate(a).empty(),"local audio blocked");
    a=one(0);a.questions[0].f["title"]=std::string(30001,'a');check(!validate(a).empty(),"Excel text limit");
    a=one(0);a.questions[0].f["title"]="Bad\x01 text";check(!validate(a).empty(),"XML control characters blocked");
    a=one(0);a.questions[0].choices[0].text="неоконченный | ответ";a.questions[0].f["title"]="";check(projectText(readProject(projectText(a)))==projectText(a),"unfinished draft with reserved symbols is preserved");
    a.questions.clear();check(!validate(a).empty(),"empty project export blocked");check(readProject(projectText(a)).questions.empty(),"empty draft can be saved");
    bool thrown=false;try{readProject("{\"format\":\"foreign\"}");}catch(...){thrown=true;}check(thrown,"foreign files rejected");
    thrown=false;try{readProject("{broken");}catch(...){thrown=true;}check(thrown,"broken JSON rejected");
    thrown=false;auto j=projectJson(p);j["version"]=2;try{readProject(j.dump());}catch(...){thrown=true;}check(thrown,"unknown project versions rejected");
    thrown=false;j=projectJson(p);j["questions"][0]["fields"]["type"]="no_such_type";try{readProject(j.dump());}catch(...){thrown=true;}check(thrown,"unknown question types rejected");
    check(crc32("123456789")==0xcbf43926,"ZIP CRC32 standard vector");
    check(xml("<&>\"'\r")=="&lt;&amp;&gt;&quot;&apos;&#13;","XML escaping");
    check(csvCell("x;\"y\"\n")=="\"x;\"\"y\"\"\n\"","CSV escaping");
    check(exportCsv(p).substr(0,3)=="\xef\xbb\xbf","CSV BOM");
    check(exportXlsx(p).substr(0,4)=="PK\x03\x04","XLSX is a real ZIP package");
    check(json::parse(exportJson(p))["questions"].size()==13,"JSON export 13 structured questions");
    check(number("-1.2e3")&&!number("NaN")&&!number("1junk")&&!number("inf"),"strict finite decimal parser");
    check(Question{}.hidePoints,"new questions hide points by default");
    check(parseExtra("MIN=0\nmax=10; min=99")["min"]=="0","extras: newlines, ASCII case and first occurrence");
    check(normalizeLines("a\r\nb\rc\nd")=="a\nb\nc\nd","line endings normalized");
    a=one(0);a.questions[0].f["title"]=" First line\r\nSecond line ";check(toRow(a.questions[0])["title"]=="First line\nSecond line","consistent exported line endings");
    check(json::parse(exportJson(a))["questions"][0]["title"]=="First line\nSecond line","JSON line endings match tables");
    a=one(0);a.questions[0].f["extra"]="shufle=1";check(!validate(a).empty(),"unknown extra parameters blocked");
    a=one(5);a.questions[0].setParam("match","excat");check(!validate(a).empty(),"invalid text mode blocked");
    a=one(8);a.questions[0].setParam("mode","unknown");check(!validate(a).empty(),"invalid blank mode blocked");
    a=one(0);a.questions[0].f["shared_text_id"]="Текст 1";check(!validate(a).empty(),"invalid shared text ID blocked");
    a=one(6);a.questions[0].pairs[0].right="Париж^2";check(!validate(a).empty(),"reserved pair score suffix blocked");
    a=one(7);a.questions[0].items[0]="Этап^2";check(!validate(a).empty(),"reserved sequence score suffix blocked");
    check(json::parse(exportJson(p))["questions"][0]["options"]["choices"][2]["is_correct"]==1,"JSON structured correct answer");
    check(json::parse(exportJson(p))["questions"][6]["options"]["pairs"].size()==4,"JSON structured matching pairs");
    a=one(5);a.questions[0].answers=std::vector<std::string>(1100,"черновик");check(readProject(projectText(a)).questions[0].answers.size()==1100,"long unfinished answer draft remains readable");check(!validate(a).empty(),"export answer count bound");
    a=one(7);a.questions[0].items=std::vector<std::string>(1100,"элемент");check(readProject(projectText(a)).questions[0].items.size()==1100,"long unfinished ordering draft remains readable");check(!validate(a).empty(),"export ordering count bound");
    if(argc>1){std::filesystem::path dir=argv[1];std::filesystem::create_directories(dir);write(dir/"sample.wpoq",projectText(p));write(dir/"questions.xlsx",exportXlsx(p));write(dir/"questions.csv",exportCsv(p));write(dir/"questions.json",exportJson(p));
        auto special=p;special.name="Кириллица & кавычки";special.questions[0].f["title"]="Проверка ; \"кавычек\", <тегов> & строки\nВторая строка: ё ∑ π ≥ 你好";special.questions[0].f["content"]="<p>Текст &amp; <b>HTML</b></p>";special.questions[0].hidePoints=false;write(dir/"special.xlsx",exportXlsx(special));write(dir/"special.csv",exportCsv(special));write(dir/"special.json",exportJson(special));
    }
    std::cout<<"RESULT "<<passed<<" passed, "<<failed<<" failed\n";return failed?1:0;
}
